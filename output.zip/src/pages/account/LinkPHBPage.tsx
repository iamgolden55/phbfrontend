import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

// Sample data for hospitals - in a real app, this would come from an API
const HOSPITALS = [
  { id: 1, name: 'Khartoum General Hospital', region: 'Khartoum', available: true },
  { id: 2, name: 'Lagos University Teaching Hospital', region: 'Lagos', available: true },
  { id: 3, name: 'Muhimbili National Hospital', region: 'Dar es Salaam', available: true },
  { id: 4, name: 'Korle Bu Teaching Hospital', region: 'Accra', available: true },
  { id: 5, name: 'Kenyatta National Hospital', region: 'Nairobi', available: true },
  { id: 6, name: 'University Teaching Hospital', region: 'Lusaka', available: true },
  { id: 7, name: 'Chris Hani Baragwanath Hospital', region: 'Johannesburg', available: true },
  { id: 8, name: 'Yaoundé Central Hospital', region: 'Yaoundé', available: true },
  { id: 9, name: 'Tikur Anbessa Specialized Hospital', region: 'Addis Ababa', available: true },
  { id: 10, name: 'University of Nigeria Teaching Hospital', region: 'Enugu', available: true },
  { id: 11, name: 'Mulago National Referral Hospital', region: 'Kampala', available: true },
  { id: 12, name: 'Hopital General de Reference de Kinshasa', region: 'Kinshasa', available: false },
  { id: 13, name: 'Centre Hospitalier Universitaire de Brazzaville', region: 'Brazzaville', available: true },
  { id: 14, name: 'Centre Hospitalier National Yalgado Ouédraogo', region: 'Ouagadougou', available: true },
  { id: 15, name: 'Dakar Principal Hospital', region: 'Dakar', available: true },
];

const LinkPHBPage: React.FC = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRegion, setSelectedRegion] = useState('');
  const [selectedHospital, setSelectedHospital] = useState<number | null>(null);
  const [phbNumber, setPhbNumber] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Extract unique regions from hospitals
  const regions = Array.from(new Set(HOSPITALS.map(hospital => hospital.region))).sort();

  // Filter hospitals by search term and selected region
  const filteredHospitals = HOSPITALS.filter(hospital => {
    const matchesSearch = searchTerm === '' ||
      hospital.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      hospital.region.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesRegion = selectedRegion === '' || hospital.region === selectedRegion;

    return matchesSearch && matchesRegion;
  });

  const handleHospitalSelect = (hospitalId: number) => {
    setSelectedHospital(hospitalId);
    setError('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Validate the PHB number
    if (!phbNumber.trim()) {
      setError('Please enter your PHB number');
      return;
    }

    // Validate that a hospital is selected
    if (!selectedHospital) {
      setError('Please select a hospital');
      return;
    }

    // In a real app, this would call an API to link the PHB number with the hospital
    setIsSubmitting(true);

    // Simulate API call with timeout
    setTimeout(() => {
      setIsSubmitting(false);
      setSuccess('Your PHB number has been successfully linked to the selected hospital.');

      // Redirect after successful linking
      setTimeout(() => {
        navigate('/account');
      }, 3000);
    }, 1500);
  };

  return (
    <div className="bg-white">
      <div className="bg-[#005eb8] text-white py-8">
        <div className="phb-container">
          <h1 className="text-3xl font-bold mb-4">Link PHB Number to Hospital</h1>
          <p className="text-xl font-medium">
            Link your PHB number to your primary hospital to access appointment booking and other services
          </p>
        </div>
      </div>

      <div className="phb-container py-8">
        <div className="bg-blue-50 border-l-4 border-blue-500 p-4 mb-8">
          <h2 className="text-xl font-bold mb-2 text-blue-800">Why link your PHB number?</h2>
          <p className="mb-2 text-blue-700">
            You must link your PHB number to a primary hospital before you can:
          </p>
          <ul className="list-disc pl-6 text-blue-700 mb-2">
            <li>Book appointments</li>
            <li>Request prescriptions</li>
            <li>Access lab results</li>
            <li>Receive referrals to specialists</li>
          </ul>
          <p className="text-blue-700">
            This linking process ensures your medical records are properly maintained and available to healthcare providers when needed.
          </p>
        </div>

        {success ? (
          <div className="bg-green-50 border-l-4 border-green-500 p-4 mb-8">
            <h2 className="text-xl font-bold mb-2 text-green-800">Success!</h2>
            <p className="text-green-700">{success}</p>
            <p className="text-green-700 mt-2">Redirecting you to your account page...</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="mb-8">
            <div className="bg-white rounded-lg shadow p-6 mb-6">
              <h2 className="text-xl font-bold mb-4">1. Enter your PHB number</h2>
              <div className="mb-4">
                <label htmlFor="phbNumber" className="block text-sm font-medium text-gray-700 mb-1">
                  PHB Number
                </label>
                <input
                  type="text"
                  id="phbNumber"
                  value={phbNumber}
                  onChange={(e) => setPhbNumber(e.target.value)}
                  placeholder="e.g., PHB1234567890"
                  className="w-full md:w-1/2 px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
                <p className="text-sm text-gray-500 mt-1">
                  Your PHB number can be found on your PHB card or in your welcome email
                </p>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow p-6 mb-6">
              <h2 className="text-xl font-bold mb-4">2. Select your primary hospital</h2>

              <div className="mb-4">
                <label htmlFor="region" className="block text-sm font-medium text-gray-700 mb-1">
                  Filter by region (optional)
                </label>
                <select
                  id="region"
                  value={selectedRegion}
                  onChange={(e) => setSelectedRegion(e.target.value)}
                  className="w-full md:w-1/2 px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">All regions</option>
                  {regions.map(region => (
                    <option key={region} value={region}>{region}</option>
                  ))}
                </select>
              </div>

              <div className="mb-4">
                <label htmlFor="search" className="block text-sm font-medium text-gray-700 mb-1">
                  Search for a hospital
                </label>
                <input
                  type="text"
                  id="search"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search by hospital name or region"
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="mt-6">
                <h3 className="font-medium mb-3">Select a hospital from the list:</h3>
                {filteredHospitals.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {filteredHospitals.map(hospital => (
                      <div
                        key={hospital.id}
                        onClick={() => hospital.available && handleHospitalSelect(hospital.id)}
                        className={`p-4 border rounded-md cursor-pointer transition-colors ${
                          hospital.available
                            ? selectedHospital === hospital.id
                              ? 'border-blue-500 bg-blue-50'
                              : 'border-gray-200 hover:border-blue-300'
                            : 'border-gray-200 bg-gray-100 opacity-60 cursor-not-allowed'
                        }`}
                      >
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="font-bold text-gray-800">{hospital.name}</h4>
                            <p className="text-gray-600 text-sm">{hospital.region}</p>
                          </div>
                          {!hospital.available && (
                            <span className="text-xs bg-red-100 text-red-800 px-2 py-1 rounded">
                              Not available
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-6 bg-gray-50 rounded-md">
                    <p className="text-gray-500">No hospitals found matching your search criteria</p>
                  </div>
                )}
              </div>
            </div>

            {error && (
              <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
                <p className="text-red-700">{error}</p>
              </div>
            )}

            <div className="flex items-center justify-between">
              <button
                type="submit"
                disabled={isSubmitting}
                className={`px-6 py-3 bg-[#005eb8] text-white font-medium rounded-md hover:bg-[#004a93] transition-colors ${
                  isSubmitting ? 'opacity-70 cursor-not-allowed' : ''
                }`}
              >
                {isSubmitting ? 'Processing...' : 'Link PHB Number'}
              </button>
              <Link
                to="/account"
                className="text-[#005eb8] hover:underline"
              >
                Cancel and return to account
              </Link>
            </div>
          </form>
        )}

        <div className="bg-gray-50 rounded-lg p-6">
          <h2 className="text-xl font-bold mb-4">Need help?</h2>
          <p className="mb-4">
            If you're having trouble linking your PHB number or have questions, you can:
          </p>
          <ul className="list-disc pl-6 space-y-2">
            <li>
              <Link to="/help/find-phb-number" className="text-[#005eb8] hover:underline">
                Find your PHB number
              </Link>
            </li>
            <li>
              <Link to="/account/contact-support" className="text-[#005eb8] hover:underline">
                Contact PHB support
              </Link>
            </li>
            <li>
              <Link to="/faq/linking-phb" className="text-[#005eb8] hover:underline">
                View the linking FAQ
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default LinkPHBPage;
