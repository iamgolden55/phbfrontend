import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from './authContext';

const OTPVerification: React.FC = () => {
  const { verifyOTP, resendOTP, otpError, clearError, isLoading } = useAuth();
  const [otp, setOtp] = useState<string[]>(Array(6).fill(''));
  const [secondsLeft, setSecondsLeft] = useState<number>(60);
  const [canResend, setCanResend] = useState<boolean>(false);
  const inputRefs = useRef<(HTMLInputElement | null)[]>(Array(6).fill(null));

  // Focus on first input when component mounts
  useEffect(() => {
    if (inputRefs.current[0]) {
      inputRefs.current[0].focus();
    }
  }, []);

  // Timer for OTP resend
  useEffect(() => {
    if (secondsLeft > 0 && !canResend) {
      const timer = setTimeout(() => setSecondsLeft(prev => prev - 1), 1000);
      return () => clearTimeout(timer);
    } else if (secondsLeft === 0 && !canResend) {
      setCanResend(true);
    }
  }, [secondsLeft, canResend]);

  const handleChange = (index: number, value: string) => {
    // Only allow digits
    if (/^\d?$/.test(value)) {
      const newOtp = [...otp];
      newOtp[index] = value;
      setOtp(newOtp);
      clearError();

      // Move focus to next input if value exists
      if (value && index < 5 && inputRefs.current[index + 1]) {
        inputRefs.current[index + 1].focus();
      }

      // Check if all digits are filled and submit automatically
      if (newOtp.every(digit => digit !== '')) {
        handleSubmit(newOtp.join(''));
      }
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    // Move focus to previous input on backspace if current input is empty
    if (e.key === 'Backspace' && !otp[index] && index > 0 && inputRefs.current[index - 1]) {
      inputRefs.current[index - 1].focus();
    }
  };

  const handleSubmit = async (otpValue?: string) => {
    const otpToSubmit = otpValue || otp.join('');
    if (otpToSubmit.length === 6) {
      await verifyOTP(otpToSubmit);
    }
  };

  const handleResendOTP = async () => {
    await resendOTP();
    setSecondsLeft(60);
    setCanResend(false);
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const pastedData = e.clipboardData.getData('text');
    const pastedOTP = pastedData.replace(/\D/g, '').slice(0, 6).split('');

    if (pastedOTP.length) {
      const newOtp = [...otp];
      pastedOTP.forEach((digit, index) => {
        if (index < 6) {
          newOtp[index] = digit;
        }
      });
      setOtp(newOtp);

      // Focus on the next empty input after pasting
      const nextEmptyIndex = newOtp.findIndex(digit => digit === '');
      if (nextEmptyIndex !== -1 && inputRefs.current[nextEmptyIndex]) {
        inputRefs.current[nextEmptyIndex].focus();
      } else if (inputRefs.current[5]) {
        // If all inputs are filled, focus on the last one
        inputRefs.current[5].focus();
      }

      // Check if all digits are filled and submit automatically
      if (newOtp.every(digit => digit !== '')) {
        handleSubmit(newOtp.join(''));
      }
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <h2 className="text-2xl font-bold mb-4">Verification Required</h2>
      <p className="mb-6 text-gray-600">
        For additional security, please enter the 6-digit code sent to your email.
      </p>

      {otpError && (
        <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-red-700">{otpError}</p>
            </div>
          </div>
        </div>
      )}

      <div className="flex justify-between space-x-2 mb-6" onPaste={handlePaste}>
        {otp.map((digit, index) => (
          <input
            key={index}
            ref={el => inputRefs.current[index] = el}
            type="text"
            value={digit}
            onChange={e => handleChange(index, e.target.value)}
            onKeyDown={e => handleKeyDown(index, e)}
            maxLength={1}
            className="w-full h-14 text-center text-xl border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#005eb8]"
            inputMode="numeric"
            autoComplete="one-time-code"
          />
        ))}
      </div>

      <button
        onClick={() => handleSubmit()}
        className="w-full bg-[#005eb8] text-white py-3 px-4 rounded hover:bg-[#003f7e] transition-colors mb-4 disabled:opacity-50"
        disabled={otp.some(digit => digit === '') || isLoading}
      >
        {isLoading ? 'Verifying...' : 'Verify'}
      </button>

      <div className="text-center">
        <p className="text-gray-600 mb-2">
          Didn't receive a code?
        </p>
        {canResend ? (
          <button
            onClick={handleResendOTP}
            className="text-[#005eb8] hover:underline"
            disabled={isLoading}
          >
            Resend Code
          </button>
        ) : (
          <p className="text-gray-500">
            Resend in <span className="font-semibold">{secondsLeft}s</span>
          </p>
        )}
      </div>

      <div className="mt-6 pt-4 border-t border-gray-200 text-center">
        <p className="text-gray-600">
          Having trouble? <button onClick={() => window.location.href='/login'} className="text-[#005eb8] hover:underline">Return to login</button>
        </p>
      </div>
    </div>
  );
};

export default OTPVerification;
