import React, { createContext, useState, useContext, useEffect, ReactNode } from 'react';

// Define types for our user and auth context
interface User {
  id: string;
  name: string;
  email: string;
  nhsNumber?: string;
  gender?: string;
  dateOfBirth?: string;
  phoneNumber?: string;
  country?: string;
  state?: string;
  city?: string;
  nin?: string;
  ssn?: string;
  completedOnboarding?: boolean;
  address?: string;
  phone?: string;
  contactPreferences?: {
    emailNotifications: boolean;
    smsNotifications: boolean;
    appointmentReminders: boolean;
    healthTips: boolean;
    serviceUpdates: boolean;
    researchParticipation: boolean;
  };
}

interface RegisterData {
  name: string;
  email: string;
  password: string;
  gender?: string;
  dateOfBirth?: string;
  phoneNumber?: string;
  country?: string;
  state?: string;
  city?: string;
  nin?: string;
  ssn?: string;
}

interface UserProfileUpdateData {
  name?: string;
  email?: string;
  dateOfBirth?: string;
  address?: string;
  phone?: string;
}

interface ContactPreferencesData {
  emailNotifications: boolean;
  smsNotifications: boolean;
  appointmentReminders: boolean;
  healthTips: boolean;
  serviceUpdates: boolean;
  researchParticipation: boolean;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  isNewUser: boolean;
  needsOnboarding: boolean;
  completeOnboarding: () => void;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  register: (
    name: string,
    email: string,
    password: string,
    extraData?: {
      gender?: string;
      dateOfBirth?: string;
      phoneNumber?: string;
      country?: string;
      state?: string;
      city?: string;
      nin?: string;
      ssn?: string;
    }
  ) => Promise<void>;
  error: string | null;
  clearError: () => void;
  // OTP-related properties
  otpVerification: boolean;
  verifyOTP: (otp: string) => Promise<void>;
  resendOTP: () => Promise<void>;
  otpError: string | null;
  pendingUser: User | null;
  createTestUser: () => User; // Add function to create a test user
  // New functions for account management
  updateUserProfile: (data: UserProfileUpdateData) => void;
  updateContactPreferences: (preferences: ContactPreferencesData) => void;
  changePassword: (currentPassword: string, newPassword: string) => void;
}

// Create the context with a default value
const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Sample users for demo purposes
const sampleUsers: User[] = [
  {
    id: '1',
    name: 'John Smith',
    email: 'john@example.com',
    nhsNumber: '123 456 7890',
    gender: 'male',
    dateOfBirth: '1980-05-15',
    phoneNumber: '+44 7700 900123',
    country: 'GB',
    state: 'London',
    city: 'London',
    completedOnboarding: true,
    address: '123 Oxford Street, London',
    phone: '+44 7700 900123',
    contactPreferences: {
      emailNotifications: true,
      smsNotifications: false,
      appointmentReminders: true,
      healthTips: true,
      serviceUpdates: true,
      researchParticipation: false,
    },
  },
  {
    id: '2',
    name: 'Jane Doe',
    email: 'jane@example.com',
    nhsNumber: '234 567 8901',
    gender: 'female',
    dateOfBirth: '1985-08-22',
    phoneNumber: '+44 7700 900456',
    country: 'GB',
    state: 'Manchester',
    city: 'Manchester',
    completedOnboarding: true,
    address: '45 Portland Street, Manchester',
    phone: '+44 7700 900456',
    contactPreferences: {
      emailNotifications: true,
      smsNotifications: true,
      appointmentReminders: true,
      healthTips: false,
      serviceUpdates: false,
      researchParticipation: true,
    },
  },
];

// Create a provider component
export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [pendingUser, setPendingUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [otpError, setOtpError] = useState<string | null>(null);
  const [otpVerification, setOtpVerification] = useState<boolean>(false);
  const [isNewUser, setIsNewUser] = useState<boolean>(false);

  // Check if user is already logged in
  useEffect(() => {
    const storedUser = localStorage.getItem('phb_user');
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser));
      } catch (err) {
        console.error('Error parsing stored user:', err);
        localStorage.removeItem('phb_user');
      }
    }
    setIsLoading(false);
  }, []);

  // DEBUG FUNCTION - Create a test user for debugging
  const createTestUser = () => {
    console.log("Creating test user for onboarding testing");
    const testUser: User = {
      id: 'test-123',
      name: 'Test User',
      email: 'test@example.com',
      completedOnboarding: false,
      address: '123 Test Street',
      phone: '+44 7700 900999',
      contactPreferences: {
        emailNotifications: true,
        smsNotifications: false,
        appointmentReminders: true,
        healthTips: false,
        serviceUpdates: false,
        researchParticipation: false,
      },
    };

    setUser(testUser);
    localStorage.setItem('phb_user', JSON.stringify(testUser));
    setIsNewUser(true);

    return testUser;
  };

  // Login function
  const login = async (email: string, password: string) => {
    setError(null);
    setIsLoading(true);
    setIsNewUser(false);

    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Find user by email
      const foundUser = sampleUsers.find(u => u.email.toLowerCase() === email.toLowerCase());

      if (!foundUser) {
        throw new Error('Invalid email or password');
      }

      // In a real app, we would validate the password here
      if (password !== 'password') {
        throw new Error('Invalid email or password');
      }

      // Instead of immediately setting user and authenticated state,
      // set the pending user and trigger OTP verification
      setPendingUser(foundUser);
      setOtpVerification(true);

    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('An unexpected error occurred');
      }
    } finally {
      setIsLoading(false);
    }
  };

  // Verify OTP function
  const verifyOTP = async (otp: string) => {
    setOtpError(null);
    setIsLoading(true);

    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Validate OTP - in a real app, this would check against a backend service
      // For demo purposes, we'll accept "123456" as the valid OTP
      if (otp !== '123456') {
        throw new Error('Invalid verification code. Please try again.');
      }

      // If OTP is valid and we have a pending user, complete the login
      if (pendingUser) {
        setUser(pendingUser);
        localStorage.setItem('phb_user', JSON.stringify(pendingUser));
        setPendingUser(null);
        setOtpVerification(false);
      } else {
        throw new Error('Login session expired. Please log in again.');
      }

    } catch (err) {
      if (err instanceof Error) {
        setOtpError(err.message);
      } else {
        setOtpError('An unexpected error occurred during verification');
      }
    } finally {
      setIsLoading(false);
    }
  };

  // Resend OTP function
  const resendOTP = async () => {
    setOtpError(null);
    setIsLoading(true);

    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));

      // In a real app, this would trigger the backend to send a new OTP
      console.log('Resending OTP for', pendingUser?.email);

      // Show success message
      setOtpError(null);

    } catch (err) {
      if (err instanceof Error) {
        setOtpError(err.message);
      } else {
        setOtpError('Failed to resend verification code');
      }
    } finally {
      setIsLoading(false);
    }
  };

  // Logout function
  const logout = () => {
    setUser(null);
    localStorage.removeItem('phb_user');
  };

  // Register function (mock)
  const register = async (
    name: string,
    email: string,
    password: string,
    extraData?: {
      gender?: string;
      dateOfBirth?: string;
      phoneNumber?: string;
      country?: string;
      state?: string;
      city?: string;
      nin?: string;
      ssn?: string;
    }
  ) => {
    setError(null);
    setIsLoading(true);
    setIsNewUser(true);

    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Check if email already exists
      if (sampleUsers.some(u => u.email.toLowerCase() === email.toLowerCase())) {
        throw new Error('Email is already in use');
      }

      // Create new user with additional fields
      const newUser: User = {
        id: String(sampleUsers.length + 1),
        name,
        email,
        completedOnboarding: false,
        ...extraData
      };

      // In a real app, we would save the user to a database here
      // For demo purposes, we'll just log it and pretend it worked
      console.log('Registered new user:', newUser);

      // Instead of immediately logging in the new user,
      // set the pending user and trigger OTP verification
      setPendingUser(newUser);
      setOtpVerification(true);

    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('An unexpected error occurred');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const clearError = () => {
    setError(null);
    setOtpError(null);
  };

  const completeOnboarding = () => {
    if (user) {
      const updatedUser = { ...user, completedOnboarding: true };
      setUser(updatedUser);
      localStorage.setItem('phb_user', JSON.stringify(updatedUser));
      setIsNewUser(false);
    }
  };

  // Function to update user profile
  const updateUserProfile = (data: UserProfileUpdateData) => {
    if (user) {
      const updatedUser = { ...user, ...data };
      setUser(updatedUser);
      localStorage.setItem('phb_user', JSON.stringify(updatedUser));
      console.log('User profile updated:', updatedUser);
    }
  };

  // Function to update contact preferences
  const updateContactPreferences = (preferences: ContactPreferencesData) => {
    if (user) {
      const updatedUser = {
        ...user,
        contactPreferences: preferences
      };
      setUser(updatedUser);
      localStorage.setItem('phb_user', JSON.stringify(updatedUser));
      console.log('Contact preferences updated:', preferences);
    }
  };

  // Function to change password
  const changePassword = (currentPassword: string, newPassword: string) => {
    // In a real app, this would validate the current password and call an API
    // Mock implementation for demo purposes
    if (currentPassword !== 'password') {
      throw new Error('Current password is incorrect');
    }

    console.log('Password changed successfully');
    // No need to update user state as we don't store the password in the front-end
  };

  const contextValue: AuthContextType = {
    user,
    isAuthenticated: !!user,
    isLoading,
    isNewUser,
    needsOnboarding: !!user && !user.completedOnboarding,
    completeOnboarding,
    login,
    logout,
    register,
    error,
    clearError,
    otpVerification,
    verifyOTP,
    resendOTP,
    otpError,
    pendingUser,
    createTestUser,
    updateUserProfile,
    updateContactPreferences,
    changePassword,
  };

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
};

// Create a custom hook to use the auth context
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export default AuthContext;
