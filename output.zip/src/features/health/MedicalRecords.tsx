import React, { useState, useEffect } from 'react';
import { useAuth } from '../auth/authContext';
import { Link } from 'react-router-dom';
import AccountHealthLayout from '../../layouts/AccountHealthLayout';

const MedicalRecords = () => {
  const { user } = useAuth();
  const [isVerified, setIsVerified] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [otpError, setOtpError] = useState('');
  const [selectedRecordId, setSelectedRecordId] = useState(null);
  const [filterCategory, setFilterCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [showSharingModal, setShowSharingModal] = useState(false);
  const [sharingPurpose, setSharingPurpose] = useState('');
  const [sharingRecipient, setSharingRecipient] = useState('');
  const [sharingConsent, setSharingConsent] = useState(false);

  // Sample medical records
  const medicalRecords = [
    {
      id: '1',
      date: '2023-12-18',
      provider: 'Central City Hospital',
      title: 'Annual Physical Examination',
      summary: 'Comprehensive physical examination with no significant findings.',
      details: 'Blood pressure: 118/76 mmHg\nPulse: 72 bpm\nTemperature: 36.6°C\nWeight: 72 kg\nHeight: 178 cm\nBMI: 22.7\n\nGeneral physical examination shows all systems functioning within normal parameters.',
      category: 'general',
      files: []
    },
    {
      id: '2',
      date: '2023-10-05',
      provider: 'Dr. Williams, Cardiology Specialist',
      title: 'Cardiac Screening',
      summary: 'Routine cardiac screening with ECG and echocardiogram.',
      details: 'ECG: Normal sinus rhythm, no arrhythmias detected.\nEchocardiogram: Normal cardiac structure and function.',
      category: 'diagnostic',
      files: [
        { name: 'echocardiogram_report.pdf', type: 'PDF', size: '2.4 MB' }
      ]
    },
    {
      id: '3',
      date: '2023-03-09',
      provider: 'Metropolitan Surgical Center',
      title: 'Appendectomy Procedure',
      summary: 'Laparoscopic appendectomy for acute appendicitis.',
      details: 'Procedure: Laparoscopic appendectomy\nDuration: 45 minutes\nFindings: Inflamed appendix without perforation',
      category: 'surgery',
      files: [
        { name: 'surgical_report.pdf', type: 'PDF', size: '3.2 MB' }
      ]
    },
    {
      id: '4',
      date: '2023-01-15',
      provider: 'PHB Vaccination Clinic',
      title: 'COVID-19 Vaccination',
      summary: 'Administration of COVID-19 booster vaccine.',
      details: 'Vaccine: COVID-19 mRNA Booster (Pfizer-BioNTech)\nBatch: BT7382\nSite: Left deltoid',
      category: 'immunization',
      files: []
    }
  ];

  // Get selected record
  const selectedRecord = selectedRecordId
    ? medicalRecords.find(r => r.id === selectedRecordId)
    : null;

  // Filter records based on category and search term
  const filteredRecords = medicalRecords.filter(record => {
    const matchesCategory = filterCategory === 'all' || record.category === filterCategory;
    const matchesSearch = searchTerm === '' ||
      record.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.summary.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Format date
  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-GB', options);
  };

  // Handle OTP verification
  const handleVerifyOTP = () => {
    setIsVerifying(true);
    setTimeout(() => {
      if (otpCode === '123456') {
        setIsVerified(true);
        setOtpError('');
      } else {
        setOtpError('Invalid verification code. Please try again.');
      }
      setIsVerifying(false);
    }, 1000);
  };

  // Handle Face ID verification (simplified)
  const handleFaceIDVerification = () => {
    setIsVerifying(true);
    setTimeout(() => {
      setIsVerified(true);
      setIsVerifying(false);
    }, 1500);
  };

  // Handle record sharing
  const handleShareRecord = () => {
    if (!sharingPurpose || !sharingRecipient || !sharingConsent) {
      return;
    }

    alert(`Medical record successfully shared with ${sharingRecipient}`);
    setShowSharingModal(false);
    setSharingPurpose('');
    setSharingRecipient('');
    setSharingConsent(false);
  };

  // Get category label
  const getCategoryLabel = (category) => {
    const labels = {
      general: 'General',
      diagnostic: 'Diagnostic',
      treatment: 'Treatment',
      immunization: 'Immunization',
      surgery: 'Surgery',
      emergency: 'Emergency'
    };
    return labels[category] || 'Other';
  };

  // Auto-verify with code 123456
  useEffect(() => {
    if (otpCode === '123456') {
      handleVerifyOTP();
    }
  }, [otpCode]);

  // Verification Screen
  const renderVerificationScreen = () => (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold mb-2">Secure Verification Required</h2>
        <p className="text-gray-600">
          Your medical records contain sensitive information and require verification to access.
        </p>
      </div>

      <div className="max-w-md mx-auto">
        <div className="mb-6">
          <h3 className="font-medium mb-3">Choose verification method:</h3>
          <div className="flex gap-4">
            <button
              className="flex-1 py-3 px-4 rounded-md bg-[#005eb8] text-white"
              onClick={() => {}}
            >
              One-Time Code
            </button>
            <button
              className="flex-1 py-3 px-4 rounded-md bg-gray-100"
              onClick={handleFaceIDVerification}
            >
              Face ID
            </button>
          </div>
        </div>

        <div>
          <div className="mb-4">
            <label className="block font-medium mb-1">Verification Code</label>
            <div className="flex gap-2">
              <input
                type="text"
                maxLength={6}
                className="w-full px-4 py-2 border border-gray-300 rounded"
                placeholder="Enter 6-digit code"
                value={otpCode}
                onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ''))}
              />
              <button className="bg-gray-100 px-4 py-2 rounded">
                Send Code
              </button>
            </div>
            {otpError && (
              <p className="text-red-600 text-sm mt-1">{otpError}</p>
            )}
          </div>

          <div className="mt-6">
            <button
              onClick={handleVerifyOTP}
              className="w-full bg-[#005eb8] text-white py-3 px-4 rounded"
              disabled={isVerifying || otpCode.length !== 6}
            >
              {isVerifying ? 'Verifying...' : 'Verify and Access Records'}
            </button>
          </div>
        </div>

        <div className="mt-6 text-center text-sm text-gray-500">
          <p>
            For demo purposes, use code: <strong>123456</strong>
          </p>
        </div>
      </div>
    </div>
  );

  // Records display after verification
  const renderRecords = () => (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Complete Medical Records</h2>
        <div className="text-sm text-gray-500">
          PHB Number: <span className="font-medium">{user?.nhsNumber || '123 456 7890'}</span>
        </div>
      </div>

      {/* Search and filters */}
      <div className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="flex flex-1 max-w-md">
          <input
            type="search"
            placeholder="Search records..."
            className="px-4 py-2 border border-gray-300 rounded-l-md w-full"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <button className="bg-[#005eb8] text-white px-4 py-2 rounded-r-md">
            <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </button>
        </div>

        <div className="flex gap-2 overflow-x-auto pb-2 md:pb-0">
          <button
            onClick={() => setFilterCategory('all')}
            className={`px-3 py-1 text-sm rounded-full whitespace-nowrap ${
              filterCategory === 'all' ? 'bg-[#005eb8] text-white' : 'bg-gray-100'
            }`}
          >
            All
          </button>
          {['general', 'diagnostic', 'surgery', 'immunization'].map((category) => (
            <button
              key={category}
              onClick={() => setFilterCategory(category)}
              className={`px-3 py-1 text-sm rounded-full whitespace-nowrap ${
                filterCategory === category ? 'bg-[#005eb8] text-white' : 'bg-gray-100'
              }`}
            >
              {getCategoryLabel(category)}
            </button>
          ))}
        </div>
      </div>

      {/* Records list and detail view */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Records list */}
        <div className="lg:col-span-1 border rounded-md overflow-hidden h-[600px] flex flex-col">
          <div className="bg-gray-50 px-4 py-3 border-b">
            <h3 className="font-bold">Medical Records</h3>
          </div>

          <div className="overflow-y-auto flex-grow">
            {filteredRecords.length > 0 ? (
              <ul className="divide-y divide-gray-200">
                {filteredRecords.map((record) => (
                  <li
                    key={record.id}
                    className={`p-4 cursor-pointer hover:bg-gray-50 ${selectedRecordId === record.id ? 'bg-blue-50' : ''}`}
                    onClick={() => setSelectedRecordId(record.id)}
                  >
                    <div className="flex items-start gap-3">
                      <div className="flex-grow min-w-0">
                        <div className="flex justify-between items-start">
                          <h4 className="font-medium text-[#005eb8] truncate">{record.title}</h4>
                          <span className="text-xs text-gray-500 whitespace-nowrap ml-2">{formatDate(record.date)}</span>
                        </div>
                        <p className="text-sm text-gray-600 truncate">{record.summary}</p>
                        <p className="text-xs text-gray-500 mt-1">{record.provider}</p>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <div className="p-6 text-center">
                <p className="text-gray-500">No records found matching your criteria.</p>
              </div>
            )}
          </div>
        </div>

        {/* Detail view */}
        <div className="lg:col-span-2 border rounded-md overflow-hidden h-[600px] flex flex-col">
          {selectedRecord ? (
            <>
              <div className="bg-gray-50 px-6 py-4 border-b">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-xl">{selectedRecord.title}</h3>
                  <span className="bg-gray-200 text-gray-700 px-3 py-1 rounded-full text-sm">
                    {getCategoryLabel(selectedRecord.category)}
                  </span>
                </div>
                <p className="text-gray-600 mt-1">{selectedRecord.provider} • {formatDate(selectedRecord.date)}</p>
              </div>

              <div className="p-6 overflow-y-auto flex-grow">
                <div className="mb-6">
                  <h4 className="font-medium text-gray-700 mb-2">Summary</h4>
                  <p>{selectedRecord.summary}</p>
                </div>

                {selectedRecord.details && (
                  <div className="mb-6">
                    <h4 className="font-medium text-gray-700 mb-2">Details</h4>
                    <div className="bg-gray-50 p-4 rounded-md whitespace-pre-line">
                      {selectedRecord.details}
                    </div>
                  </div>
                )}

                {selectedRecord.files.length > 0 && (
                  <div>
                    <h4 className="font-medium text-gray-700 mb-2">Files & Documents</h4>
                    <ul className="divide-y divide-gray-200 border rounded-md">
                      {selectedRecord.files.map((file, index) => (
                        <li key={index} className="p-3 flex items-center justify-between">
                          <div className="flex items-center">
                            <div>
                              <p className="font-medium">{file.name}</p>
                              <p className="text-xs text-gray-500">{file.type} • {file.size}</p>
                            </div>
                          </div>
                          <a href="#" className="text-[#005eb8] hover:underline ml-4 text-sm">
                            View
                          </a>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              <div className="bg-gray-50 px-6 py-3 border-t flex justify-between">
                <button
                  className="text-gray-600 hover:text-gray-900 flex items-center text-sm"
                  onClick={() => setSelectedRecordId(null)}
                >
                  <svg className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                  </svg>
                  Back to list
                </button>

                <div className="flex gap-2">
                  <button className="bg-white border border-gray-300 text-gray-700 px-3 py-1 rounded-md text-sm hover:bg-gray-50">
                    Print
                  </button>
                  <button className="bg-white border border-gray-300 text-gray-700 px-3 py-1 rounded-md text-sm hover:bg-gray-50">
                    Download
                  </button>
                  <button
                    className="bg-[#005eb8] text-white px-3 py-1 rounded-md text-sm hover:bg-[#003f7e]"
                    onClick={() => setShowSharingModal(true)}
                  >
                    Share Record
                  </button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex items-center justify-center h-full text-center p-6">
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-1">No record selected</h3>
                <p className="text-gray-500">Select a record from the list to view its details.</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Information and help */}
      <div className="mt-6 bg-blue-50 p-4 rounded-md">
        <h3 className="font-bold text-blue-800 mb-2">About your medical records</h3>
        <p className="text-blue-700 text-sm mb-4">
          Your complete medical records contain detailed information about your health history,
          including visits to hospitals, clinics, and specialist care providers.
        </p>
      </div>

      {/* Sharing Modal */}
      {showSharingModal && selectedRecord && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <h3 className="text-xl font-bold">Share Medical Record</h3>
                <button
                  onClick={() => setShowSharingModal(false)}
                  className="text-gray-400 hover:text-gray-500"
                >
                  <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>

              <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-6">
                <div className="flex">
                  <div className="ml-3">
                    <h3 className="text-sm font-medium text-yellow-800">Important Privacy Notice</h3>
                    <div className="mt-1 text-sm text-yellow-700">
                      <p>Sharing your medical records with external organizations may affect your privacy.
                      Only share with trusted organizations for legitimate purposes.</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mb-4">
                <p className="text-sm text-gray-600 mb-3">
                  You are about to share the following record:
                </p>
                <div className="bg-gray-50 p-3 rounded-md mb-3">
                  <h4 className="font-medium">{selectedRecord.title}</h4>
                  <p className="text-sm text-gray-600">{formatDate(selectedRecord.date)} • {selectedRecord.provider}</p>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Recipient (Organization or Individual)*
                  </label>
                  <input
                    type="text"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    placeholder="Enter recipient name"
                    value={sharingRecipient}
                    onChange={(e) => setSharingRecipient(e.target.value)}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Purpose of Sharing*
                  </label>
                  <textarea
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    placeholder="Explain why you need to share this record"
                    rows={3}
                    value={sharingPurpose}
                    onChange={(e) => setSharingPurpose(e.target.value)}
                  />
                </div>

                <div className="flex items-start">
                  <div className="flex items-center h-5">
                    <input
                      id="consent"
                      type="checkbox"
                      className="h-4 w-4 border-gray-300 rounded"
                      checked={sharingConsent}
                      onChange={(e) => setSharingConsent(e.target.checked)}
                    />
                  </div>
                  <div className="ml-3 text-sm">
                    <label htmlFor="consent" className="font-medium text-gray-700">
                      I consent to share this medical record
                    </label>
                    <p className="text-gray-500">
                      I understand that I am sharing my confidential medical information with an external organization.
                    </p>
                  </div>
                </div>
              </div>

              <div className="mt-6 flex justify-end gap-3">
                <button
                  type="button"
                  className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700"
                  onClick={() => setShowSharingModal(false)}
                >
                  Cancel
                </button>
                <button
                  type="button"
                  className={`px-4 py-2 rounded-md text-sm font-medium text-white ${
                    !sharingPurpose || !sharingRecipient || !sharingConsent
                      ? 'bg-gray-400 cursor-not-allowed'
                      : 'bg-[#005eb8]'
                  }`}
                  onClick={handleShareRecord}
                  disabled={!sharingPurpose || !sharingRecipient || !sharingConsent}
                >
                  Share Record
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  return (
    <AccountHealthLayout title="Complete Medical Records">
      {!isVerified ? renderVerificationScreen() : renderRecords()}
    </AccountHealthLayout>
  );
};

export default MedicalRecords;
