import React from 'react';
import { Link } from 'react-router-dom';

export type SearchResultItem = {
  title: string;
  description: string;
  url: string;
  category: string;
  concepts?: string[]; // Optional array of concepts related to this item
  symptoms?: string[]; // Optional array of symptoms related to this item
};

type SearchResultsProps = {
  results: SearchResultItem[];
  isLoading: boolean;
  searchTerm: string;
  onClose: () => void;
  onResultClick?: (url: string) => void; // Optional because we might not need it in all cases
};

const SearchResults: React.FC<SearchResultsProps> = ({
  results,
  isLoading,
  searchTerm,
  onClose,
  onResultClick
}) => {
  if (searchTerm.length < 2) {
    return null;
  }

  // Handle result click with the custom handler if provided
  const handleResultClick = (url: string, event: React.MouseEvent) => {
    if (onResultClick) {
      event.preventDefault(); // Prevent default link behavior
      onResultClick(url);
    }
    onClose();
  };

  // Check if there is a notice in the first result
  const hasNotice = results.length > 0 &&
    (results[0].description.includes('Showing results for') ||
     results[0].description.includes('Showing similar results') ||
     results[0].description.includes('Showing results related to'));

  // Extract the notice if it exists
  let notice = '';
  let originalDescription = '';

  if (hasNotice && results.length > 0) {
    const desc = results[0].description;
    const noticePart = desc.substring(0, desc.indexOf('.') + 1);
    originalDescription = desc.substring(desc.indexOf('.') + 1).trim();
    notice = noticePart;
  }

  // Determine notice type for styling
  const isSpellingCorrection = notice.includes('Showing results for');
  const isConceptSearch = notice.includes('Showing results related to');
  const isFuzzySearch = notice.includes('Showing similar results');

  // Define notice style based on type
  let noticeStyle = "px-4 py-2 text-sm border-b";
  if (isSpellingCorrection) {
    noticeStyle += " bg-blue-50 text-blue-700 border-blue-100";
  } else if (isConceptSearch) {
    noticeStyle += " bg-green-50 text-green-700 border-green-100";
  } else if (isFuzzySearch) {
    noticeStyle += " bg-yellow-50 text-yellow-700 border-yellow-100";
  }

  return (
    <div className="bg-white rounded-lg shadow-lg border border-gray-200 z-50 pointer-events-auto">
      <div className="flex justify-between items-center p-4 border-b border-gray-200">
        <h3 className="font-semibold">
          {isLoading ? (
            'Searching...'
          ) : results.length > 0 ? (
            `Results for "${searchTerm}"`
          ) : (
            `No results for "${searchTerm}"`
          )}
        </h3>
        <button
          onClick={onClose}
          className="text-gray-500 hover:text-gray-700"
          aria-label="Close search results"
        >
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
            <path strokeLinecap="round" strokeLinejoin="round" d="M6 18 18 6M6 6l12 12" />
          </svg>
        </button>
      </div>

      {/* Notice (spelling correction, concept match, etc.) */}
      {hasNotice && (
        <div className={noticeStyle}>
          {notice}
          {isSpellingCorrection && (
            <button className="underline hover:text-blue-900 ml-1">Search for exact term instead</button>
          )}
        </div>
      )}

      <div className="max-h-[80vh] overflow-y-auto">
        {isLoading ? (
          <div className="p-6 flex justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
          </div>
        ) : results.length > 0 ? (
          <ul className="divide-y divide-gray-100">
            {results.map((result, index) => {
              // Use the original description for the first item if we extracted a notice
              const description = index === 0 && hasNotice ? originalDescription : result.description;

              return (
                <li key={index} className="p-4 hover:bg-gray-50 transition-colors">
                  <Link
                    to={result.url}
                    className="block"
                    onClick={(e) => handleResultClick(result.url, e)}
                  >
                    <div className="flex items-start">
                      <div className="flex-1">
                        <span className="inline-block text-xs font-medium px-2 py-1 bg-blue-100 text-blue-800 rounded mb-1">
                          {result.category}
                        </span>
                        <h4 className="font-medium text-[#005eb8] mb-1">{result.title}</h4>
                        <p className="text-sm text-gray-600 line-clamp-2">{description}</p>
                      </div>
                      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 text-gray-400 mt-1 ml-2">
                        <path strokeLinecap="round" strokeLinejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                      </svg>
                    </div>
                  </Link>
                </li>
              );
            })}
          </ul>
        ) : (
          <div className="p-6 text-center">
            <p className="text-gray-600 mb-4">We couldn't find any results matching your search.</p>
            <div className="text-sm text-gray-500">
              <p>Try:</p>
              <ul className="list-disc pl-5 mt-2 text-left">
                <li>Checking your spelling</li>
                <li>Using fewer keywords</li>
                <li>Using more general terms</li>
                <li>Describing your symptoms more clearly</li>
              </ul>
            </div>
          </div>
        )}
      </div>

      {results.length > 0 && (
        <div className="p-4 border-t border-gray-200 text-center">
          <Link
            to={`/search?q=${encodeURIComponent(searchTerm)}`}
            className="text-[#005eb8] hover:underline text-sm font-medium"
            onClick={(e) => onResultClick ? handleResultClick(`/search?q=${encodeURIComponent(searchTerm)}`, e) : onClose()}
          >
            View all results
          </Link>
        </div>
      )}
    </div>
  );
};

export default SearchResults;
