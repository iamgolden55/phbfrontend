import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

// Layouts
import MainLayout from './layouts/MainLayout';
import ProfessionalLayout from './layouts/ProfessionalLayout';

// Pages
import HomePage from './pages/HomePage';
import HealthAZPage from './pages/HealthAZPage';
import HealthConditionPage from './pages/HealthConditionPage';
import LiveWellPage from './pages/LiveWellPage';
import MentalHealthPage from './pages/MentalHealthPage';
import CareAndSupportPage from './pages/CareAndSupportPage';
import PregnancyPage from './pages/PregnancyPage';
import PregnancyHealthPage from './pages/PregnancyHealthPage';
import PregnancyConcernsPage from './pages/PregnancyConcernsPage';
import CommonConcernsPage from './pages/CommonConcernsPage';
import FirstPrenatalVisitPage from './pages/FirstPrenatalVisitPage';
import EarlyPregnancySymptomsPage from './pages/EarlyPregnancySymptomsPage';
import PrenatalTestsPage from './pages/PrenatalTestsPage';
import SignsOfLaborPage from './pages/SignsOfLaborPage';
import PlanningPregnancyPage from './pages/PlanningPregnancyPage';
import EarlyPregnancyPage from './pages/EarlyPregnancyPage';
import MiddlePregnancyPage from './pages/MiddlePregnancyPage';
import LatePregnancyPage from './pages/LatePregnancyPage';
import LaborAndBirthPage from './pages/LaborAndBirthPage';
import AfterBirthPage from './pages/AfterBirthPage';
import PregnancyForumsPage from './pages/PregnancyForumsPage';
import BMICalculatorPage from './pages/BMICalculatorPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import AccountPage from './pages/AccountPage';
import DueDateCalculatorPage from './pages/DueDateCalculatorPage';
import KickCounterPage from './pages/KickCounterPage';
import ContractionTimerPage from './pages/ContractionTimerPage';
import WeightGainCalculatorPage from './pages/WeightGainCalculatorPage';
import PregnancyCalendarPage from './pages/PregnancyCalendarPage';
import BabyNamesDirectoryPage from './pages/BabyNamesDirectoryPage';
import BabyShowerPlannerPage from './pages/BabyShowerPlannerPage';
import PregnancyNutritionGuidePage from './pages/PregnancyNutritionGuidePage';
import BirthPlanCreatorPage from './pages/BirthPlanCreatorPage';
import AboutPHBPage from './pages/AboutPHBPage';
import ElaraAIPage from './pages/ElaraAIPage';
import PHBServicesPage from './pages/PHBServicesPage';
import LinkValidatorPage from './pages/LinkValidatorPage';
import SiteMapPage from './pages/SiteMapPage';

// Professional Pages
import ProfessionalLoginPage from './pages/professional/ProfessionalLoginPage';
import ProfessionalRegisterPage from './pages/professional/ProfessionalRegisterPage';
import ProfessionalDashboardPage from './pages/professional/ProfessionalDashboardPage';
import ProfessionalCalculatorsPage from './pages/professional/ProfessionalCalculatorsPage';
import ResearchPage from './pages/professional/ResearchPage';
import ClinicalGuidelinesPage from './pages/professional/ClinicalGuidelinesPage';
import DoctorResourcesPage from './pages/professional/DoctorResourcesPage';
import ProfessionalForumPage from './pages/professional/ProfessionalForumPage';
import PatientManagementPage from './pages/professional/PatientManagementPage';

// Features
import { AuthProvider } from './features/auth/authContext';
import { ProfessionalAuthProvider } from './features/professional/professionalAuthContext';
import ProfessionalRouteGuard from './features/professional/ProfessionalRouteGuard';
import GPHealthRecord from './features/health/GPHealthRecord';
import Prescriptions from './features/health/Prescriptions';
import Appointments from './features/health/Appointments';
import TestResults from './features/health/TestResults';

function App() {
  return (
    <AuthProvider>
      <ProfessionalAuthProvider>
        <Router>
          <Routes>
            {/* Standalone auth pages (no header/footer) */}
            <Route path="login" element={<LoginPage />} />
            <Route path="register" element={<RegisterPage />} />
            <Route path="professional/login" element={<ProfessionalLoginPage />} />
            <Route path="professional/register" element={<ProfessionalRegisterPage />} />

            {/* Main layout routes */}
            <Route path="/" element={<MainLayout />}>
              <Route index element={<HomePage />} />
              <Route path="health-a-z" element={<HealthAZPage />} />
              <Route path="health-a-z/:conditionSlug" element={<HealthConditionPage />} />
              <Route path="live-well" element={<LiveWellPage />} />
              <Route path="mental-health" element={<MentalHealthPage />} />
              <Route path="care-and-support" element={<CareAndSupportPage />} />

              {/* Pregnancy Pages */}
              <Route path="pregnancy" element={<PregnancyPage />} />
              <Route path="pregnancy/health" element={<PregnancyHealthPage />} />
              <Route path="pregnancy/forums" element={<PregnancyForumsPage />} />
              <Route path="pregnancy/calendar" element={<PregnancyCalendarPage />} />
              <Route path="pregnancy/baby-names-directory" element={<BabyNamesDirectoryPage />} />
              <Route path="pregnancy/baby-shower-planner" element={<BabyShowerPlannerPage />} />
              <Route path="pregnancy/nutrition-guide" element={<PregnancyNutritionGuidePage />} />
              <Route path="pregnancy/birth-plan-creator" element={<BirthPlanCreatorPage />} />
              <Route path="pregnancy/concerns" element={<PregnancyConcernsPage />} />
              <Route path="pregnancy/common-concerns" element={<CommonConcernsPage />} />
              <Route path="pregnancy/first-prenatal-visit" element={<FirstPrenatalVisitPage />} />
              <Route path="pregnancy/early-pregnancy-symptoms" element={<EarlyPregnancySymptomsPage />} />
              <Route path="pregnancy/prenatal-tests" element={<PrenatalTestsPage />} />
              <Route path="pregnancy/signs-of-labor" element={<SignsOfLaborPage />} />

              {/* Pregnancy Journey Pages */}
              <Route path="pregnancy/planning" element={<PlanningPregnancyPage />} />
              <Route path="pregnancy/early" element={<EarlyPregnancyPage />} />
              <Route path="pregnancy/middle" element={<MiddlePregnancyPage />} />
              <Route path="pregnancy/late" element={<LatePregnancyPage />} />
              <Route path="pregnancy/labor-and-birth" element={<LaborAndBirthPage />} />
              <Route path="pregnancy/after-birth" element={<AfterBirthPage />} />

              {/* Tools */}
              <Route path="tools/bmi-calculator" element={<BMICalculatorPage />} />
              <Route path="tools/due-date-calculator" element={<DueDateCalculatorPage />} />
              <Route path="tools/kick-counter" element={<KickCounterPage />} />
              <Route path="tools/contraction-timer" element={<ContractionTimerPage />} />
              <Route path="tools/weight-gain-calculator" element={<WeightGainCalculatorPage />} />

              {/* Account and Health Dashboard */}
              <Route path="account" element={<AccountPage />} />
              <Route path="account/gp-record" element={<GPHealthRecord />} />
              <Route path="account/prescriptions" element={<Prescriptions />} />
              <Route path="account/appointments" element={<Appointments />} />
              <Route path="account/test-results" element={<TestResults />} />

              {/* About and Additional Pages */}
              <Route path="about" element={<AboutPHBPage />} />
              <Route path="elara-ai" element={<ElaraAIPage />} />
              <Route path="phb-services" element={<PHBServicesPage />} />
              <Route path="link-validator" element={<LinkValidatorPage />} />
              <Route path="site-map" element={<SiteMapPage />} />
            </Route>

            {/* Professional layout routes */}
            <Route path="/professional" element={<ProfessionalLayout />}>
              <Route path="dashboard" element={
                <ProfessionalRouteGuard>
                  <ProfessionalDashboardPage />
                </ProfessionalRouteGuard>
              } />

              {/* Patient Management */}
              <Route path="patients" element={
                <ProfessionalRouteGuard>
                  <PatientManagementPage />
                </ProfessionalRouteGuard>
              } />

              {/* Clinical Guidelines */}
              <Route path="guidelines" element={
                <ProfessionalRouteGuard>
                  <ClinicalGuidelinesPage />
                </ProfessionalRouteGuard>
              } />

              {/* Doctor Resources */}
              <Route path="resources" element={
                <ProfessionalRouteGuard>
                  <DoctorResourcesPage />
                </ProfessionalRouteGuard>
              } />

              {/* Professional Forum */}
              <Route path="forum" element={
                <ProfessionalRouteGuard>
                  <ProfessionalForumPage />
                </ProfessionalRouteGuard>
              } />

              {/* Clinical Calculators */}
              <Route path="calculators" element={
                <ProfessionalRouteGuard>
                  <ProfessionalCalculatorsPage />
                </ProfessionalRouteGuard>
              } />

              {/* Research Portal */}
              <Route path="research" element={
                <ProfessionalRouteGuard allowedRoles={['researcher', 'doctor']}>
                  <ResearchPage />
                </ProfessionalRouteGuard>
              } />
            </Route>

            {/* Catch all for 404 - can be replaced with a NotFoundPage component */}
            <Route path="*" element={<div className="min-h-screen flex items-center justify-center text-center p-4">
              <div>
                <h1 className="text-4xl font-bold text-blue-700 mb-4">Page Not Found</h1>
                <p className="text-lg mb-6">The page you are looking for might have been removed or is temporarily unavailable.</p>
                <a href="/" className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 transition-colors">
                  Return to Home
                </a>
              </div>
            </div>} />
          </Routes>
        </Router>
      </ProfessionalAuthProvider>
    </AuthProvider>
  );
}

export default App;
