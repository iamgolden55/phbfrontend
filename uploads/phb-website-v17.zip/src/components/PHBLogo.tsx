import React from 'react';

interface PHBLogoProps {
  className?: string;
}

const PHBLogo: React.FC<PHBLogoProps> = ({ className }) => {
  return (
    <div className={`text-white ${className}`}>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 100 40"
        width="100"
        height="40"
        className="w-20 h-8"
      >
        <rect width="100" height="40" fill="#005eb8" />
        <text
          x="50%"
          y="50%"
          dominantBaseline="middle"
          textAnchor="middle"
          fill="white"
          fontSize="24"
          fontWeight="bold"
          fontFamily="Arial, sans-serif"
        >
          PHB
        </text>
      </svg>
    </div>
  );
};

export default PHBLogo;
