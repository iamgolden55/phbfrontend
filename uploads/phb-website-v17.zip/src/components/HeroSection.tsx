import React from 'react';

const HeroSection: React.FC = () => {
  return (
    <section className="bg-[#005eb8] text-white relative pb-0 overflow-hidden">
      <div className="phb-container py-8 md:py-12">
        <div className="max-w-xl md:max-w-2xl pb-8 md:pb-12 pt-4 z-10 relative">
          <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold mb-4">
            PHB website for the country
          </h1>
          <p className="text-xl md:text-2xl font-medium">
            Find information and services to help you manage your health
          </p>
        </div>
      </div>
      {/* Hero background image */}
      <div className="absolute right-0 bottom-0 h-full w-1/2 overflow-hidden hidden md:block">
        <img
          src="https://ext.same-assets.com/2399685259/916310909.png"
          alt="Healthcare professional checking patients records"
          className="object-cover h-full w-full object-left"
        />
      </div>
    </section>
  );
};

export default HeroSection;
