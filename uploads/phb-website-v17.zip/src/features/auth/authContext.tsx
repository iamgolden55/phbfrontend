import React, { createContext, useState, useContext, useEffect, ReactNode } from 'react';

// Define types for our user and auth context
interface User {
  id: string;
  name: string;
  email: string;
  nhsNumber?: string;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  register: (name: string, email: string, password: string) => Promise<void>;
  error: string | null;
  clearError: () => void;
}

// Create the context with a default value
const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Sample users for demo purposes
const sampleUsers: User[] = [
  {
    id: '1',
    name: 'John Smith',
    email: 'john@example.com',
    nhsNumber: '123 456 7890',
  },
  {
    id: '2',
    name: 'Jane Doe',
    email: 'jane@example.com',
    nhsNumber: '234 567 8901',
  },
];

// Create a provider component
export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Check if user is already logged in
  useEffect(() => {
    const storedUser = localStorage.getItem('phb_user');
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser));
      } catch (err) {
        console.error('Error parsing stored user:', err);
        localStorage.removeItem('phb_user');
      }
    }
    setIsLoading(false);
  }, []);

  // Login function
  const login = async (email: string, password: string) => {
    setError(null);
    setIsLoading(true);

    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Find user by email
      const foundUser = sampleUsers.find(u => u.email.toLowerCase() === email.toLowerCase());

      if (!foundUser) {
        throw new Error('Invalid email or password');
      }

      // In a real app, we would validate the password here
      if (password !== 'password') {
        throw new Error('Invalid email or password');
      }

      // Store user in state and localStorage
      setUser(foundUser);
      localStorage.setItem('phb_user', JSON.stringify(foundUser));

    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('An unexpected error occurred');
      }
    } finally {
      setIsLoading(false);
    }
  };

  // Logout function
  const logout = () => {
    setUser(null);
    localStorage.removeItem('phb_user');
  };

  // Register function (mock)
  const register = async (name: string, email: string, password: string) => {
    setError(null);
    setIsLoading(true);

    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Check if email already exists
      if (sampleUsers.some(u => u.email.toLowerCase() === email.toLowerCase())) {
        throw new Error('Email is already in use');
      }

      // Create new user
      const newUser: User = {
        id: String(sampleUsers.length + 1),
        name,
        email,
      };

      // In a real app, we would save the user to a database here
      // For demo purposes, we'll just log it and pretend it worked
      console.log('Registered new user:', newUser);

      // "Log in" the new user
      setUser(newUser);
      localStorage.setItem('phb_user', JSON.stringify(newUser));

    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('An unexpected error occurred');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const clearError = () => {
    setError(null);
  };

  const contextValue: AuthContextType = {
    user,
    isAuthenticated: !!user,
    isLoading,
    login,
    logout,
    register,
    error,
    clearError,
  };

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
};

// Create a custom hook to use the auth context
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export default AuthContext;
