import React, { useState } from 'react';
import { useAuth } from './authContext';
import { Link } from 'react-router-dom';

const RegisterForm: React.FC = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [agreeToTerms, setAgreeToTerms] = useState(false);
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  const { register, isLoading, error, clearError } = useAuth();

  const validateForm = (): boolean => {
    const errors: Record<string, string> = {};

    // Validate name
    if (!name.trim()) {
      errors.name = 'Name is required';
    }

    // Validate email
    if (!email) {
      errors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      errors.email = 'Email is invalid';
    }

    // Validate password
    if (!password) {
      errors.password = 'Password is required';
    } else if (password.length < 8) {
      errors.password = 'Password must be at least 8 characters long';
    }

    // Validate password confirmation
    if (password !== confirmPassword) {
      errors.confirmPassword = 'Passwords do not match';
    }

    // Validate terms agreement
    if (!agreeToTerms) {
      errors.agreeToTerms = 'You must agree to the terms and conditions';
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    clearError();

    if (validateForm()) {
      await register(name, email, password);
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <h2 className="text-2xl font-bold mb-6">Create your PHB account</h2>

      {error && (
        <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-red-700">{error}</p>
            </div>
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label htmlFor="name" className="block font-medium mb-1">
            Full name
          </label>
          <input
            type="text"
            id="name"
            className={`w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#005eb8] ${
              formErrors.name ? 'border-red-500' : 'border-gray-300'
            }`}
            value={name}
            onChange={(e) => { setName(e.target.value); clearError(); }}
            placeholder="Enter your full name"
          />
          {formErrors.name && (
            <p className="mt-1 text-red-500 text-sm">{formErrors.name}</p>
          )}
        </div>

        <div className="mb-4">
          <label htmlFor="email" className="block font-medium mb-1">
            Email address
          </label>
          <input
            type="email"
            id="email"
            className={`w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#005eb8] ${
              formErrors.email ? 'border-red-500' : 'border-gray-300'
            }`}
            value={email}
            onChange={(e) => { setEmail(e.target.value); clearError(); }}
            placeholder="Enter your email"
          />
          {formErrors.email && (
            <p className="mt-1 text-red-500 text-sm">{formErrors.email}</p>
          )}
        </div>

        <div className="mb-4">
          <label htmlFor="password" className="block font-medium mb-1">
            Password
          </label>
          <input
            type="password"
            id="password"
            className={`w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#005eb8] ${
              formErrors.password ? 'border-red-500' : 'border-gray-300'
            }`}
            value={password}
            onChange={(e) => { setPassword(e.target.value); clearError(); }}
            placeholder="Create a password"
          />
          {formErrors.password ? (
            <p className="mt-1 text-red-500 text-sm">{formErrors.password}</p>
          ) : (
            <p className="mt-1 text-gray-500 text-sm">Password must be at least 8 characters long</p>
          )}
        </div>

        <div className="mb-6">
          <label htmlFor="confirmPassword" className="block font-medium mb-1">
            Confirm password
          </label>
          <input
            type="password"
            id="confirmPassword"
            className={`w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#005eb8] ${
              formErrors.confirmPassword ? 'border-red-500' : 'border-gray-300'
            }`}
            value={confirmPassword}
            onChange={(e) => { setConfirmPassword(e.target.value); clearError(); }}
            placeholder="Confirm your password"
          />
          {formErrors.confirmPassword && (
            <p className="mt-1 text-red-500 text-sm">{formErrors.confirmPassword}</p>
          )}
        </div>

        <div className="mb-6">
          <div className="flex items-start">
            <div className="flex items-center h-5">
              <input
                type="checkbox"
                id="terms"
                className="h-4 w-4 text-[#005eb8] border-gray-300 rounded focus:ring-[#005eb8]"
                checked={agreeToTerms}
                onChange={(e) => setAgreeToTerms(e.target.checked)}
              />
            </div>
            <div className="ml-3 text-sm">
              <label htmlFor="terms" className="text-gray-700">
                I agree to the{' '}
                <Link to="/terms" className="text-[#005eb8] hover:underline">
                  Terms and Conditions
                </Link>
                {' '}and{' '}
                <Link to="/privacy" className="text-[#005eb8] hover:underline">
                  Privacy Policy
                </Link>
              </label>
              {formErrors.agreeToTerms && (
                <p className="mt-1 text-red-500">{formErrors.agreeToTerms}</p>
              )}
            </div>
          </div>
        </div>

        <button
          type="submit"
          className="w-full bg-[#005eb8] text-white py-2 px-4 rounded hover:bg-[#003f7e] transition-colors"
          disabled={isLoading}
        >
          {isLoading ? 'Creating account...' : 'Create account'}
        </button>
      </form>

      <div className="mt-6 pt-4 border-t border-gray-200 text-center">
        <p className="text-gray-600">
          Already have an account?{' '}
          <Link to="/login" className="text-[#005eb8] hover:underline">
            Sign in
          </Link>
        </p>
      </div>
    </div>
  );
};

export default RegisterForm;
