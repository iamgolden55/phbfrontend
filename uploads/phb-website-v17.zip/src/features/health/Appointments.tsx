import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../auth/authContext';
import AccountHealthLayout from '../../layouts/AccountHealthLayout';

interface AppointmentType {
  id: string;
  date: string;
  time: string;
  duration: string;
  type: 'in-person' | 'phone' | 'video';
  provider: string;
  location: string;
  status: 'scheduled' | 'cancelled' | 'completed' | 'missed';
  reason?: string;
}

// Sample appointments for demonstration
const mockAppointments: AppointmentType[] = [
  {
    id: 'a1',
    date: '2023-11-15',
    time: '09:30',
    duration: '15 min',
    type: 'in-person',
    provider: 'Dr. Sarah Johnson',
    location: 'Main Street Medical Practice',
    status: 'scheduled',
    reason: 'Regular check-up'
  },
  {
    id: 'a2',
    date: '2023-10-25',
    time: '14:15',
    duration: '10 min',
    type: 'phone',
    provider: 'Dr. Michael Brown',
    location: 'Main Street Medical Practice',
    status: 'completed',
    reason: 'Medication review'
  },
  {
    id: 'a3',
    date: '2023-09-18',
    time: '11:00',
    duration: '20 min',
    type: 'video',
    provider: 'Dr. James Wilson',
    location: 'Online consultation',
    status: 'completed',
    reason: 'Follow-up after test results'
  },
  {
    id: 'a4',
    date: '2023-09-05',
    time: '10:30',
    duration: '15 min',
    type: 'in-person',
    provider: 'Nurse Claire Davis',
    location: 'Main Street Medical Practice',
    status: 'completed',
    reason: 'Vaccination'
  },
  {
    id: 'a5',
    date: '2023-08-10',
    time: '15:45',
    duration: '10 min',
    type: 'phone',
    provider: 'Dr. Sarah Johnson',
    location: 'Main Street Medical Practice',
    status: 'missed',
  },
];

const Appointments: React.FC = () => {
  const { user } = useAuth();
  const [view, setView] = useState<'upcoming' | 'past' | 'all'>('upcoming');
  const [selectedAppointment, setSelectedAppointment] = useState<AppointmentType | null>(null);
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [cancelReason, setCancelReason] = useState('');

  // Filter appointments based on current view
  const filteredAppointments = mockAppointments.filter(appointment => {
    const appointmentDate = new Date(appointment.date);
    const today = new Date();
    today.setHours(0, 0, 0, 0); // Set to beginning of day for comparison

    if (view === 'upcoming') return appointmentDate >= today && appointment.status === 'scheduled';
    if (view === 'past') return appointmentDate < today || appointment.status !== 'scheduled';
    return true; // 'all' view
  }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-GB', options);
  };

  const formatDateTime = (date: string, time: string) => {
    return `${formatDate(date)} at ${time}`;
  };

  const getAppointmentTypeIcon = (type: string) => {
    switch (type) {
      case 'in-person':
        return (
          <div className="bg-green-100 p-2 rounded-full">
            <svg className="h-5 w-5 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
            </svg>
          </div>
        );
      case 'phone':
        return (
          <div className="bg-blue-100 p-2 rounded-full">
            <svg className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
            </svg>
          </div>
        );
      case 'video':
        return (
          <div className="bg-purple-100 p-2 rounded-full">
            <svg className="h-5 w-5 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
            </svg>
          </div>
        );
      default:
        return (
          <div className="bg-gray-100 p-2 rounded-full">
            <svg className="h-5 w-5 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
          </div>
        );
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'scheduled': return 'Scheduled';
      case 'cancelled': return 'Cancelled';
      case 'completed': return 'Completed';
      case 'missed': return 'Missed';
      default: return status;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'scheduled': return 'text-green-600 bg-green-50';
      case 'cancelled': return 'text-red-600 bg-red-50';
      case 'completed': return 'text-blue-600 bg-blue-50';
      case 'missed': return 'text-yellow-600 bg-yellow-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  const handleCancelAppointment = (appointment: AppointmentType) => {
    setSelectedAppointment(appointment);
    setShowCancelModal(true);
  };

  const submitCancellation = () => {
    console.log('Cancellation submitted for:', selectedAppointment?.id, 'Reason:', cancelReason);
    setShowCancelModal(false);
    setCancelReason('');
    // In a real app, this would update the appointment status and trigger API calls
  };

  return (
    <AccountHealthLayout title="Appointments">
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h2 className="text-2xl font-bold mb-6">Your Appointments</h2>

        <div className="mb-6">
          <p>
            Book and manage appointments with your GP, nurse, or other healthcare professionals. You can view your upcoming and past appointments, reschedule or cancel appointments as needed.
          </p>
        </div>

        {/* Appointments features would go here */}
        {/* Placeholder content until we implement the full appointments functionality */}
        <div className="bg-blue-50 p-4 rounded-md mb-6">
          <div className="flex items-start">
            <div className="bg-blue-100 p-2 rounded-full mr-3">
              <svg className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div>
              <h3 className="font-bold text-blue-800">Coming Soon</h3>
              <p className="text-blue-700 text-sm">
                We're currently developing the appointments feature. You'll soon be able to book and manage appointments online.
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-gray-50 p-6 rounded-lg">
            <h3 className="text-xl font-bold mb-4">Book an appointment</h3>
            <p className="mb-4">
              Book an appointment with your GP, nurse, or other healthcare professionals.
            </p>
            <button className="bg-[#005eb8] text-white px-4 py-2 rounded-md hover:bg-[#003f7e] transition-colors">
              Book now
            </button>
          </div>

          <div className="bg-gray-50 p-6 rounded-lg">
            <h3 className="text-xl font-bold mb-4">View your appointments</h3>
            <p className="mb-4">
              View your upcoming and past appointments, and manage your schedule.
            </p>
            <button className="bg-[#005eb8] text-white px-4 py-2 rounded-md hover:bg-[#003f7e] transition-colors">
              View appointments
            </button>
          </div>
        </div>

        <div className="mt-8">
          <h3 className="text-xl font-bold mb-4">Need help with appointments?</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Link
              to="/help/appointments/booking"
              className="bg-white border border-gray-200 p-4 rounded-md hover:shadow-md transition-shadow"
            >
              <h4 className="font-bold text-[#005eb8] mb-2">How to book</h4>
              <p className="text-sm text-gray-600">Learn how to book appointments online with your GP practice.</p>
            </Link>

            <Link
              to="/help/appointments/managing"
              className="bg-white border border-gray-200 p-4 rounded-md hover:shadow-md transition-shadow"
            >
              <h4 className="font-bold text-[#005eb8] mb-2">Managing appointments</h4>
              <p className="text-sm text-gray-600">Information about rescheduling or cancelling appointments.</p>
            </Link>

            <Link
              to="/help/appointments/types"
              className="bg-white border border-gray-200 p-4 rounded-md hover:shadow-md transition-shadow"
            >
              <h4 className="font-bold text-[#005eb8] mb-2">Appointment types</h4>
              <p className="text-sm text-gray-600">Find out about different types of appointments available.</p>
            </Link>
          </div>
        </div>
      </div>

      {/* Cancel appointment modal */}
      {showCancelModal && selectedAppointment && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-md w-full p-6">
            <h3 className="text-lg font-bold mb-4">Cancel appointment</h3>
            <p className="mb-4">
              Are you sure you want to cancel your appointment on:
            </p>
            <div className="bg-gray-50 p-3 rounded-md mb-4">
              <p className="font-bold">{formatDateTime(selectedAppointment.date, selectedAppointment.time)}</p>
              <p className="text-sm text-gray-600">{selectedAppointment.provider}</p>
              <p className="text-sm text-gray-600">{selectedAppointment.location}</p>
            </div>

            <div className="mb-4">
              <label htmlFor="cancelReason" className="block font-medium mb-1">
                Reason for cancellation (optional)
              </label>
              <textarea
                id="cancelReason"
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#005eb8]"
                value={cancelReason}
                onChange={(e) => setCancelReason(e.target.value)}
              ></textarea>
            </div>

            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowCancelModal(false)}
                className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
              >
                Keep appointment
              </button>
              <button
                onClick={submitCancellation}
                className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
              >
                Cancel appointment
              </button>
            </div>
          </div>
        </div>
      )}
    </AccountHealthLayout>
  );
};

export default Appointments;
