import React, { useState } from 'react';
import { useAuth } from '../auth/authContext';
import { Link } from 'react-router-dom';
import AccountHealthLayout from '../../layouts/AccountHealthLayout';

interface RecordType {
  id: string;
  date: string;
  provider: string;
  title: string;
  summary: string;
  details?: string;
  type: 'appointment' | 'consultation' | 'test' | 'medication' | 'referral' | 'vaccination';
}

// Sample health records for demonstration
const mockHealthRecords: RecordType[] = [
  {
    id: '1',
    date: '2023-12-15',
    provider: 'Dr. Sarah Johnson',
    title: 'Regular Check-up',
    summary: 'Annual wellness check-up. No significant concerns.',
    details: 'Blood pressure: 120/80 mmHg\nWeight: 70 kg\nHeight: 175 cm\nBMI: 22.9\nNotes: Patient reports mild seasonal allergies. Advised to continue taking antihistamines as needed.',
    type: 'consultation'
  },
  {
    id: '2',
    date: '2023-09-08',
    provider: 'City Medical Laboratory',
    title: 'Blood Test Results',
    summary: 'Complete blood count and metabolic panel. All results within normal range.',
    details: 'Hemoglobin: 14.2 g/dL (Normal)\nWhite blood cells: 7.5 x10^9/L (Normal)\nPlatelets: 250 x10^9/L (Normal)\nGlucose: 5.1 mmol/L (Normal)\nTotal cholesterol: 4.8 mmol/L (Normal)',
    type: 'test'
  },
  {
    id: '3',
    date: '2023-07-22',
    provider: 'Dr. James Wilson',
    title: 'Prescription Renewal',
    summary: 'Renewed prescription for allergy medication.',
    details: 'Medication: Cetirizine 10mg\nDosage: One tablet daily\nQuantity: 30 tablets\nRefills: 3',
    type: 'medication'
  },
  {
    id: '4',
    date: '2023-05-10',
    provider: 'Dr. Sarah Johnson',
    title: 'Influenza Vaccination',
    summary: 'Annual flu vaccine administered.',
    details: 'Vaccine: Quadrivalent Influenza Vaccine\nBatch number: FL789456\nAdministered in: Left arm\nNo immediate adverse reactions observed.',
    type: 'vaccination'
  },
  {
    id: '5',
    date: '2023-03-15',
    provider: 'Dr. Michael Brown',
    title: 'Dermatology Referral',
    summary: 'Referral to dermatology for assessment of persistent rash.',
    details: 'Referred to: Dr. Emily Chen, Dermatology\nReason: Assessment of eczema on hands and arms\nUrgency: Routine',
    type: 'referral'
  },
];

const GPHealthRecord: React.FC = () => {
  const { user } = useAuth();
  const [selectedRecord, setSelectedRecord] = useState<RecordType | null>(null);
  const [filterType, setFilterType] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');

  // Filter records based on type and search term
  const filteredRecords = mockHealthRecords.filter(record => {
    const matchesType = filterType === 'all' || record.type === filterType;
    const matchesSearch = record.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         record.summary.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         record.provider.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesType && matchesSearch;
  }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-GB', options);
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'appointment':
        return (
          <div className="bg-purple-100 p-2 rounded-full">
            <svg className="h-5 w-5 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
          </div>
        );
      case 'consultation':
        return (
          <div className="bg-blue-100 p-2 rounded-full">
            <svg className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
            </svg>
          </div>
        );
      case 'test':
        return (
          <div className="bg-yellow-100 p-2 rounded-full">
            <svg className="h-5 w-5 text-yellow-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
            </svg>
          </div>
        );
      case 'medication':
        return (
          <div className="bg-green-100 p-2 rounded-full">
            <svg className="h-5 w-5 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
          </div>
        );
      case 'referral':
        return (
          <div className="bg-orange-100 p-2 rounded-full">
            <svg className="h-5 w-5 text-orange-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
          </div>
        );
      case 'vaccination':
        return (
          <div className="bg-teal-100 p-2 rounded-full">
            <svg className="h-5 w-5 text-teal-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 11.5V14m0-2.5v-6a1.5 1.5 0 113 0m-3 6a1.5 1.5 0 00-3 0v2a7.5 7.5 0 0015 0v-5a1.5 1.5 0 00-3 0m-6-3V11m0-5.5v-1a1.5 1.5 0 013 0v1m0 0V11m0-5.5a1.5 1.5 0 013 0v3m0 0V11" />
            </svg>
          </div>
        );
      default:
        return (
          <div className="bg-gray-100 p-2 rounded-full">
            <svg className="h-5 w-5 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
            </svg>
          </div>
        );
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'appointment': return 'Appointment';
      case 'consultation': return 'Consultation';
      case 'test': return 'Test Result';
      case 'medication': return 'Medication';
      case 'referral': return 'Referral';
      case 'vaccination': return 'Vaccination';
      default: return 'Record';
    }
  };

  const recordsContent = (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">GP Health Record</h2>
        <div className="text-sm text-gray-500">
          {user?.nhsNumber ? (
            <div>PHB Number: <span className="font-medium">{user.nhsNumber}</span></div>
          ) : (
            <div className="text-yellow-600">
              PHB Number not linked. <Link to="/account/link-phb" className="text-[#005eb8] hover:underline">Link your PHB number</Link>
            </div>
          )}
        </div>
      </div>

      {/* Search and filters */}
      <div className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="flex flex-1 max-w-md">
          <input
            type="search"
            placeholder="Search records..."
            className="px-4 py-2 border border-gray-300 rounded-l-md w-full focus:outline-none focus:ring-2 focus:ring-[#005eb8]"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <button
            className="bg-[#005eb8] text-white px-4 py-2 rounded-r-md hover:bg-[#003f7e]"
          >
            <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </button>
        </div>

        <div className="flex gap-2 overflow-x-auto md:overflow-visible pb-2 md:pb-0">
          <button
            onClick={() => setFilterType('all')}
            className={`px-3 py-1 text-sm rounded-full whitespace-nowrap ${
              filterType === 'all' ? 'bg-[#005eb8] text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            All
          </button>
          {['consultation', 'test', 'medication', 'vaccination', 'referral'].map((type) => (
            <button
              key={type}
              onClick={() => setFilterType(type)}
              className={`px-3 py-1 text-sm rounded-full whitespace-nowrap ${
                filterType === type ? 'bg-[#005eb8] text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {getTypeLabel(type)}
            </button>
          ))}
        </div>
      </div>

      {/* Records list and detail view */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Records list */}
        <div className="lg:col-span-1 border rounded-md overflow-hidden h-[600px] flex flex-col">
          <div className="bg-gray-50 px-4 py-3 border-b">
            <h3 className="font-bold">Health Records</h3>
          </div>

          <div className="overflow-y-auto flex-grow">
            {filteredRecords.length > 0 ? (
              <ul className="divide-y divide-gray-200">
                {filteredRecords.map((record) => (
                  <li
                    key={record.id}
                    className={`p-4 cursor-pointer hover:bg-gray-50 ${selectedRecord?.id === record.id ? 'bg-blue-50' : ''}`}
                    onClick={() => setSelectedRecord(record)}
                  >
                    <div className="flex items-start gap-3">
                      {getTypeIcon(record.type)}
                      <div className="flex-grow min-w-0">
                        <div className="flex justify-between items-start">
                          <h4 className="font-medium text-[#005eb8] truncate">{record.title}</h4>
                          <span className="text-xs text-gray-500 whitespace-nowrap ml-2">{formatDate(record.date)}</span>
                        </div>
                        <p className="text-sm text-gray-600 truncate">{record.summary}</p>
                        <p className="text-xs text-gray-500 mt-1">{record.provider}</p>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <div className="p-6 text-center">
                <p className="text-gray-500">No records found matching your criteria.</p>
              </div>
            )}
          </div>
        </div>

        {/* Detail view */}
        <div className="lg:col-span-2 border rounded-md overflow-hidden h-[600px] flex flex-col">
          {selectedRecord ? (
            <>
              <div className="bg-gray-50 px-6 py-4 border-b">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-xl">{selectedRecord.title}</h3>
                  <span className="bg-gray-200 text-gray-700 px-3 py-1 rounded-full text-sm">
                    {getTypeLabel(selectedRecord.type)}
                  </span>
                </div>
                <p className="text-gray-600 mt-1">{selectedRecord.provider} • {formatDate(selectedRecord.date)}</p>
              </div>

              <div className="p-6 overflow-y-auto flex-grow">
                <div className="mb-6">
                  <h4 className="font-medium text-gray-700 mb-2">Summary</h4>
                  <p>{selectedRecord.summary}</p>
                </div>

                {selectedRecord.details && (
                  <div>
                    <h4 className="font-medium text-gray-700 mb-2">Details</h4>
                    <div className="bg-gray-50 p-4 rounded-md whitespace-pre-line">
                      {selectedRecord.details}
                    </div>
                  </div>
                )}
              </div>

              <div className="bg-gray-50 px-6 py-3 border-t flex justify-between">
                <button
                  className="text-gray-600 hover:text-gray-900 flex items-center text-sm"
                  onClick={() => setSelectedRecord(null)}
                >
                  <svg className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                  </svg>
                  Back to list
                </button>

                <div className="flex gap-2">
                  <button className="bg-white border border-gray-300 text-gray-700 px-3 py-1 rounded-md text-sm hover:bg-gray-50">
                    Download
                  </button>
                  <button className="bg-white border border-gray-300 text-gray-700 px-3 py-1 rounded-md text-sm hover:bg-gray-50">
                    Print
                  </button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex items-center justify-center h-full text-center p-6">
              <div>
                <svg className="h-16 w-16 text-gray-300 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                <h3 className="text-lg font-medium text-gray-900 mb-1">No record selected</h3>
                <p className="text-gray-500">Select a record from the list to view its details.</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Information and access */}
      <div className="mt-6 bg-blue-50 p-4 rounded-md">
        <h3 className="font-bold text-blue-800 mb-2">About your health record</h3>
        <p className="text-blue-700 text-sm mb-4">
          Your GP health record contains information about your health, appointments, test results, medications, and referrals.
          You can see information from all GP practices where you've been registered.
        </p>
        <div className="flex flex-col sm:flex-row gap-3">
          <Link
            to="/help/health-records"
            className="text-[#005eb8] bg-white px-4 py-2 rounded-md text-sm hover:bg-gray-50 text-center border border-[#005eb8]"
          >
            Learn more about health records
          </Link>
          <Link
            to="/account/data-sharing-preferences"
            className="text-[#005eb8] bg-white px-4 py-2 rounded-md text-sm hover:bg-gray-50 text-center border border-[#005eb8]"
          >
            Manage data sharing preferences
          </Link>
        </div>
      </div>
    </div>
  );

  return (
    <AccountHealthLayout title="GP Health Record">
      {recordsContent}
    </AccountHealthLayout>
  );
};

export default GPHealthRecord;
