import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../auth/authContext';
import AccountHealthLayout from '../../layouts/AccountHealthLayout';

interface TestResultType {
  id: string;
  date: string;
  testName: string;
  testType: string;
  orderedBy: string;
  status: 'completed' | 'pending' | 'cancelled';
  results?: {
    name: string;
    value: string;
    unit?: string;
    normalRange?: string;
    isNormal: boolean;
  }[];
  summary?: string;
  notes?: string;
}

// Sample test results for demonstration
const mockTestResults: TestResultType[] = [
  {
    id: 't1',
    date: '2023-10-15',
    testName: 'Complete Blood Count',
    testType: 'Blood',
    orderedBy: 'Dr. Sarah Johnson',
    status: 'completed',
    results: [
      {
        name: 'Hemoglobin',
        value: '14.2',
        unit: 'g/dL',
        normalRange: '13.5-17.5',
        isNormal: true
      },
      {
        name: 'White Blood Cell Count',
        value: '7.5',
        unit: 'x10^9/L',
        normalRange: '4.5-11.0',
        isNormal: true
      },
      {
        name: 'Platelet Count',
        value: '250',
        unit: 'x10^9/L',
        normalRange: '150-450',
        isNormal: true
      },
      {
        name: 'Red Blood Cell Count',
        value: '5.0',
        unit: 'x10^12/L',
        normalRange: '4.5-5.5',
        isNormal: true
      }
    ],
    summary: 'All results within normal range.'
  },
  {
    id: 't2',
    date: '2023-09-05',
    testName: 'Lipid Panel',
    testType: 'Blood',
    orderedBy: 'Dr. Michael Brown',
    status: 'completed',
    results: [
      {
        name: 'Total Cholesterol',
        value: '5.2',
        unit: 'mmol/L',
        normalRange: '<5.2',
        isNormal: true
      },
      {
        name: 'LDL Cholesterol',
        value: '3.4',
        unit: 'mmol/L',
        normalRange: '<3.4',
        isNormal: true
      },
      {
        name: 'HDL Cholesterol',
        value: '1.1',
        unit: 'mmol/L',
        normalRange: '>1.0',
        isNormal: true
      },
      {
        name: 'Triglycerides',
        value: '1.8',
        unit: 'mmol/L',
        normalRange: '<2.3',
        isNormal: true
      }
    ],
    summary: 'Cholesterol levels are at the upper limit of normal range. Recommend dietary adjustments.',
    notes: 'Consider follow-up test in 6 months. Discuss lifestyle changes at next appointment.'
  },
  {
    id: 't3',
    date: '2023-08-20',
    testName: 'Liver Function Test',
    testType: 'Blood',
    orderedBy: 'Dr. Sarah Johnson',
    status: 'completed',
    results: [
      {
        name: 'ALT',
        value: '45',
        unit: 'U/L',
        normalRange: '7-56',
        isNormal: true
      },
      {
        name: 'AST',
        value: '40',
        unit: 'U/L',
        normalRange: '10-40',
        isNormal: true
      },
      {
        name: 'Alkaline Phosphatase',
        value: '85',
        unit: 'U/L',
        normalRange: '44-147',
        isNormal: true
      },
      {
        name: 'Total Bilirubin',
        value: '0.8',
        unit: 'mg/dL',
        normalRange: '0.1-1.2',
        isNormal: true
      }
    ],
    summary: 'Liver function tests within normal limits.'
  },
  {
    id: 't4',
    date: '2023-11-01',
    testName: 'HbA1c',
    testType: 'Blood',
    orderedBy: 'Dr. James Wilson',
    status: 'pending'
  }
];

const TestResults: React.FC = () => {
  const { user } = useAuth();
  const [selectedTest, setSelectedTest] = useState<TestResultType | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  // Filter test results based on search term
  const filteredTests = mockTestResults
    .filter(test => {
      if (!searchTerm) return true;
      return (
        test.testName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        test.testType.toLowerCase().includes(searchTerm.toLowerCase()) ||
        test.orderedBy.toLowerCase().includes(searchTerm.toLowerCase())
      );
    })
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-GB', options);
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'completed': return 'Completed';
      case 'pending': return 'Pending';
      case 'cancelled': return 'Cancelled';
      default: return status;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-green-600 bg-green-50';
      case 'pending': return 'text-blue-600 bg-blue-50';
      case 'cancelled': return 'text-red-600 bg-red-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  const getResultStatusIndicator = (isNormal: boolean) => {
    return isNormal ? (
      <span className="inline-flex items-center rounded-full bg-green-50 px-2 py-1 text-xs font-medium text-green-700">
        Normal
      </span>
    ) : (
      <span className="inline-flex items-center rounded-full bg-red-50 px-2 py-1 text-xs font-medium text-red-700">
        Abnormal
      </span>
    );
  };

  return (
    <AccountHealthLayout title="Test Results">
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h2 className="text-2xl font-bold mb-6">Your Test Results</h2>

        <div className="mb-6">
          <p>
            View your test results from blood tests, scans, and other medical procedures. Results are added to your PHB account after being reviewed by your healthcare provider.
          </p>
        </div>

        {/* Test Results features would go here */}
        {/* Placeholder content until we implement the full test results functionality */}
        <div className="bg-blue-50 p-4 rounded-md mb-6">
          <div className="flex items-start">
            <div className="bg-blue-100 p-2 rounded-full mr-3">
              <svg className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div>
              <h3 className="font-bold text-blue-800">Coming Soon</h3>
              <p className="text-blue-700 text-sm">
                We're currently developing the test results feature. You'll soon be able to view your medical test results online.
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-gray-50 p-6 rounded-lg">
            <h3 className="text-xl font-bold mb-4">Recent test results</h3>
            <p className="mb-4">
              View your most recent test results from blood tests, scans, and other medical procedures.
            </p>
            <button className="bg-[#005eb8] text-white px-4 py-2 rounded-md hover:bg-[#003f7e] transition-colors">
              View recent results
            </button>
          </div>

          <div className="bg-gray-50 p-6 rounded-lg">
            <h3 className="text-xl font-bold mb-4">Search for results</h3>
            <p className="mb-4">
              Search for specific test results by date, type, or healthcare provider.
            </p>
            <button className="bg-[#005eb8] text-white px-4 py-2 rounded-md hover:bg-[#003f7e] transition-colors">
              Search results
            </button>
          </div>
        </div>

        <div className="mt-8">
          <h3 className="text-xl font-bold mb-4">Understanding your test results</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Link
              to="/help/test-results/understanding"
              className="bg-white border border-gray-200 p-4 rounded-md hover:shadow-md transition-shadow"
            >
              <h4 className="font-bold text-[#005eb8] mb-2">Reading results</h4>
              <p className="text-sm text-gray-600">Learn how to understand your test results and what the numbers mean.</p>
            </Link>

            <Link
              to="/help/test-results/reference-ranges"
              className="bg-white border border-gray-200 p-4 rounded-md hover:shadow-md transition-shadow"
            >
              <h4 className="font-bold text-[#005eb8] mb-2">Reference ranges</h4>
              <p className="text-sm text-gray-600">Information about normal reference ranges for common tests.</p>
            </Link>

            <Link
              to="/help/test-results/follow-up"
              className="bg-white border border-gray-200 p-4 rounded-md hover:shadow-md transition-shadow"
            >
              <h4 className="font-bold text-[#005eb8] mb-2">Follow-up care</h4>
              <p className="text-sm text-gray-600">Find out when and how to follow up on test results with your healthcare provider.</p>
            </Link>
          </div>
        </div>
      </div>
    </AccountHealthLayout>
  );
};

export default TestResults;
