import React from 'react';
import { Link } from 'react-router-dom';

interface ResourceType {
  title: string;
  description: string;
  href: string;
  imageSrc?: string;
  tags?: string[];
}

const mentalHealthResources: ResourceType[] = [
  {
    title: 'Depression',
    description: 'Information on depression symptoms, causes and treatments, and how you can help yourself.',
    href: '/mental-health/depression',
    imageSrc: 'https://images.unsplash.com/photo-1594839688520-77c7898072a8?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=250&q=80',
    tags: ['Common conditions', 'Mood disorders']
  },
  {
    title: 'Anxiety',
    description: 'Learn about anxiety disorders, including symptoms, causes, treatments and self-help options.',
    href: '/mental-health/anxiety',
    imageSrc: 'https://images.unsplash.com/photo-1604881988114-444286142299?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=250&q=80',
    tags: ['Common conditions', 'Anxiety disorders']
  },
  {
    title: 'Stress',
    description: 'Tips and advice on managing stress, including what triggers it and how it affects your body.',
    href: '/mental-health/stress',
    imageSrc: 'https://images.unsplash.com/photo-1541199249251-f713e6145474?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=250&q=80',
    tags: ['Common conditions', 'Self-help']
  },
  {
    title: 'Post-traumatic stress disorder (PTSD)',
    description: 'Find out about post-traumatic stress disorder (PTSD), including causes, symptoms and treatments.',
    href: '/mental-health/ptsd',
    imageSrc: 'https://images.unsplash.com/photo-1609588558629-3125a86de969?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=250&q=80',
    tags: ['Trauma-related', 'Anxiety disorders']
  },
  {
    title: 'Self-harm',
    description: 'Information and support for those who self-harm, including how to get help and coping strategies.',
    href: '/mental-health/self-harm',
    imageSrc: 'https://images.unsplash.com/photo-1590004953392-5aba2e72269a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=250&q=80',
    tags: ['Urgent support', 'Young people']
  },
  {
    title: 'Eating disorders',
    description: 'Information about eating disorders, including symptoms, causes, treatment and prevention.',
    href: '/mental-health/eating-disorders',
    imageSrc: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=250&q=80',
    tags: ['Self-image', 'Young people']
  },
];

const MentalHealthPage: React.FC = () => {
  return (
    <div className="bg-white">
      <div className="bg-[#005eb8] text-white py-8">
        <div className="phb-container">
          <h1 className="text-3xl font-bold mb-4">Mental health</h1>
          <p className="text-xl font-medium">
            Information and advice about mental health problems, services and support
          </p>
        </div>
      </div>

      <div className="phb-container py-8">
        {/* Urgent help section */}
        <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-8">
          <h2 className="text-xl font-bold mb-2 text-red-800">Urgent mental health help</h2>
          <p className="mb-4 text-red-700">
            If you or someone you know needs help for a mental health crisis or emergency, you should get help immediately.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <a
              href="tel:999"
              className="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700 transition-colors text-center font-bold"
            >
              Call 999 for immediate danger
            </a>
            <a
              href="tel:111"
              className="bg-[#005eb8] text-white px-4 py-2 rounded-md hover:bg-[#003f7e] transition-colors text-center font-bold"
            >
              Call PHB 111 for urgent advice
            </a>
          </div>
        </div>

        {/* Mental health resources */}
        <h2 className="text-2xl font-bold mb-6">Common mental health conditions</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {mentalHealthResources.map((resource, index) => (
            <div
              key={index}
              className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow flex flex-col h-full"
            >
              {resource.imageSrc && (
                <div className="h-48 overflow-hidden">
                  <img
                    src={resource.imageSrc}
                    alt={resource.title}
                    className="w-full h-full object-cover"
                  />
                </div>
              )}
              <div className="p-5 flex-grow flex flex-col">
                <h3 className="text-xl font-bold text-[#005eb8] mb-2">
                  <Link to={resource.href} className="hover:underline">
                    {resource.title}
                  </Link>
                </h3>
                <p className="text-gray-600 mb-4 flex-grow">{resource.description}</p>

                {resource.tags && resource.tags.length > 0 && (
                  <div className="flex flex-wrap gap-2 mb-4">
                    {resource.tags.map((tag, idx) => (
                      <span
                        key={idx}
                        className="bg-gray-100 text-gray-600 px-2 py-1 rounded-md text-xs"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                )}

                <Link
                  to={resource.href}
                  className="text-[#005eb8] font-medium hover:underline flex items-center mt-auto"
                >
                  Read more
                  <svg className="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </Link>
              </div>
            </div>
          ))}
        </div>

        {/* Support services */}
        <h2 className="text-2xl font-bold mb-6">Mental health services</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          <div className="bg-[#f0f4f5] p-6 rounded-lg">
            <h3 className="text-xl font-bold mb-3">PHB talking therapies</h3>
            <p className="mb-4">
              PHB talking therapies (IAPT) are free psychological therapies, like cognitive behavioural therapy (CBT).
              They can help with common mental health problems like stress, anxiety and depression.
            </p>
            <Link
              to="/services/talking-therapies"
              className="phb-button inline-block"
            >
              Find an PHB talking therapies service
            </Link>
          </div>

          <div className="bg-[#f0f4f5] p-6 rounded-lg">
            <h3 className="text-xl font-bold mb-3">Mental health services for young people</h3>
            <p className="mb-4">
              If you're a young person experiencing mental health problems, there are services available specifically for you.
            </p>
            <Link
              to="/services/young-people-mental-health"
              className="phb-button inline-block"
            >
              Young people's mental health services
            </Link>
          </div>
        </div>

        {/* Self-help and advice */}
        <h2 className="text-2xl font-bold mb-6">Self-help and wellbeing</h2>
        <div className="bg-white p-6 border border-gray-200 rounded-lg shadow-sm mb-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h3 className="font-bold mb-3">Improve mental wellbeing</h3>
              <p className="text-sm text-gray-600 mb-2">
                5 steps to mental wellbeing that can help you feel more positive and get the most out of life.
              </p>
              <Link to="/mental-health/wellbeing" className="text-[#005eb8] text-sm hover:underline">
                5 steps to wellbeing
              </Link>
            </div>

            <div>
              <h3 className="font-bold mb-3">Sleep and mental health</h3>
              <p className="text-sm text-gray-600 mb-2">
                Find out how to improve your sleep when you have mental health problems, and how poor sleep can affect your mental health.
              </p>
              <Link to="/mental-health/sleep" className="text-[#005eb8] text-sm hover:underline">
                Sleep tips
              </Link>
            </div>

            <div>
              <h3 className="font-bold mb-3">Mindfulness</h3>
              <p className="text-sm text-gray-600 mb-2">
                Learn how mindfulness can help improve your mental wellbeing, and how to practice it.
              </p>
              <Link to="/mental-health/mindfulness" className="text-[#005eb8] text-sm hover:underline">
                Mindfulness guide
              </Link>
            </div>
          </div>
        </div>

        {/* Mental health assessment tool */}
        <div className="bg-[#005eb8] text-white p-8 rounded-lg">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-2xl font-bold mb-4">Mental health self-assessment</h2>
            <p className="mb-6">
              If you're concerned about your mental health, take our short assessment to get personalized advice and resources.
            </p>
            <Link
              to="/tools/mental-health-assessment"
              className="bg-white text-[#005eb8] px-6 py-3 rounded-md hover:bg-gray-100 transition-colors inline-block font-bold"
            >
              Take the assessment
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MentalHealthPage;
