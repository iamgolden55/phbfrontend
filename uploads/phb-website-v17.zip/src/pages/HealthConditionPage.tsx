import React from 'react';
import { useParams, Link } from 'react-router-dom';

// Define a type for health condition data
interface ConditionDetail {
  name: string;
  overview: string;
  symptoms: string[];
  causes: string[];
  treatments: string[];
  whenToSeek: string;
  prevention: string[];
  relatedConditions: string[];
}

// Sample data for asthma condition
const asthmaData: ConditionDetail = {
  name: 'Asthma',
  overview: 'Asthma is a common long-term condition that affects the airways in the lungs. It causes inflammation and narrowing of the bronchial tubes, which leads to breathing difficulty, wheezing, coughing, and shortness of breath.',
  symptoms: [
    'Wheezing (a whistling sound when breathing)',
    'Breathlessness',
    'A tight chest – it may feel like a band is tightening around your chest',
    'Coughing, particularly at night or early in the morning',
    'Attacks triggered by exercise, exposure to allergens, cold air, or respiratory infections'
  ],
  causes: [
    'Allergies (such as to pollen, animal dander, dust mites)',
    'Respiratory infections',
    'Air pollutants (such as smoke)',
    'Cold air',
    'Exercise',
    'Stress',
    'Genetic factors'
  ],
  treatments: [
    'Inhalers – devices that let you breathe in medicine',
    'Preventers – inhalers that help prevent symptoms (usually containing corticosteroids)',
    'Relievers – inhalers that treat symptoms when they occur (containing medicines such as salbutamol)',
    'Tablets to help control asthma (such as leukotriene receptor antagonists)',
    'Theophylline tablets to help with breathing',
    'Steroid tablets for more severe attacks',
    'Injections for severe asthma (biological therapy)'
  ],
  whenToSeek: 'Call 999 if you or someone else is having an asthma attack and your symptoms do not improve after using your inhaler, you cannot speak or breathe properly, or your lips or skin turn blue.',
  prevention: [
    'Avoid known triggers',
    'Get vaccinated against flu and pneumonia',
    'Identify and treat attacks early',
    'Take your medications as prescribed',
    'Monitor your breathing regularly',
    'Follow your asthma action plan'
  ],
  relatedConditions: [
    'Allergic rhinitis',
    'Sinusitis',
    'Gastroesophageal reflux disease (GERD)',
    'Bronchitis',
    'COPD'
  ]
};

// Mapping of condition slugs to data (in a real app, this would come from an API)
const conditionDataMap: Record<string, ConditionDetail> = {
  'asthma': asthmaData,
  // Add more conditions here
};

const HealthConditionPage: React.FC = () => {
  const { conditionSlug } = useParams<{ conditionSlug: string }>();

  // Get condition data based on the slug parameter
  const condition = conditionSlug ? conditionDataMap[conditionSlug] : null;

  if (!condition) {
    return (
      <div className="bg-white">
        <div className="bg-[#005eb8] text-white py-8">
          <div className="phb-container">
            <h1 className="text-3xl font-bold mb-4">Condition not found</h1>
          </div>
        </div>
        <div className="phb-container py-8">
          <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-6">
            <p className="text-yellow-700">
              Sorry, we couldn't find information about this condition.
            </p>
          </div>
          <Link to="/health-a-z" className="phb-link">
            Return to Health A-Z
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white">
      {/* Header */}
      <div className="bg-[#005eb8] text-white py-8">
        <div className="phb-container">
          <div className="flex items-center gap-2 mb-4">
            <Link to="/health-a-z" className="text-white hover:underline">
              Health A-Z
            </Link>
            <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
            <span>{condition.name}</span>
          </div>
          <h1 className="text-3xl font-bold">{condition.name}</h1>
        </div>
      </div>

      {/* Main content */}
      <div className="phb-container py-8">
        {/* Emergency warning if applicable */}
        {condition.whenToSeek && (
          <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg className="h-5 w-5 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
              </div>
              <div className="ml-3">
                <h3 className="text-lg font-medium text-red-700">When to seek emergency help</h3>
                <div className="mt-2 text-red-700">
                  <p>{condition.whenToSeek}</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Overview */}
        <section className="mb-8">
          <h2 className="text-2xl font-bold mb-4">About {condition.name}</h2>
          <p className="text-lg mb-4">{condition.overview}</p>
        </section>

        {/* Table of contents */}
        <section className="mb-8 bg-gray-50 p-6 rounded-md">
          <h2 className="text-xl font-bold mb-4">On this page</h2>
          <ul className="space-y-2">
            <li>
              <a href="#symptoms" className="phb-link">Symptoms</a>
            </li>
            <li>
              <a href="#causes" className="phb-link">Causes</a>
            </li>
            <li>
              <a href="#treatments" className="phb-link">Treatments</a>
            </li>
            <li>
              <a href="#prevention" className="phb-link">Prevention</a>
            </li>
            <li>
              <a href="#related" className="phb-link">Related conditions</a>
            </li>
          </ul>
        </section>

        {/* Symptoms */}
        <section id="symptoms" className="mb-8 scroll-mt-4">
          <h2 className="text-2xl font-bold mb-4 text-[#005eb8]">Symptoms of {condition.name}</h2>
          <p className="mb-4">Common symptoms of {condition.name.toLowerCase()} include:</p>
          <ul className="list-disc pl-6 space-y-2">
            {condition.symptoms.map((symptom, index) => (
              <li key={index}>{symptom}</li>
            ))}
          </ul>
        </section>

        {/* Causes */}
        <section id="causes" className="mb-8 scroll-mt-4">
          <h2 className="text-2xl font-bold mb-4 text-[#005eb8]">Causes of {condition.name}</h2>
          <p className="mb-4">{condition.name} can be caused or triggered by:</p>
          <ul className="list-disc pl-6 space-y-2">
            {condition.causes.map((cause, index) => (
              <li key={index}>{cause}</li>
            ))}
          </ul>
        </section>

        {/* Treatments */}
        <section id="treatments" className="mb-8 scroll-mt-4">
          <h2 className="text-2xl font-bold mb-4 text-[#005eb8]">Treatments for {condition.name}</h2>
          <p className="mb-4">Treatment options for {condition.name.toLowerCase()} include:</p>
          <ul className="list-disc pl-6 space-y-2">
            {condition.treatments.map((treatment, index) => (
              <li key={index}>{treatment}</li>
            ))}
          </ul>
        </section>

        {/* Prevention */}
        <section id="prevention" className="mb-8 scroll-mt-4">
          <h2 className="text-2xl font-bold mb-4 text-[#005eb8]">Prevention and management</h2>
          <p className="mb-4">Ways to manage and prevent {condition.name.toLowerCase()} symptoms:</p>
          <ul className="list-disc pl-6 space-y-2">
            {condition.prevention.map((tip, index) => (
              <li key={index}>{tip}</li>
            ))}
          </ul>
        </section>

        {/* Related conditions */}
        <section id="related" className="mb-8 scroll-mt-4">
          <h2 className="text-2xl font-bold mb-4 text-[#005eb8]">Related conditions</h2>
          <p className="mb-4">Conditions that are often associated with {condition.name.toLowerCase()}:</p>
          <ul className="list-disc pl-6 space-y-2">
            {condition.relatedConditions.map((relatedCondition, index) => (
              <li key={index}>{relatedCondition}</li>
            ))}
          </ul>
        </section>

        {/* Further resources */}
        <section className="bg-gray-50 p-6 rounded-md">
          <h2 className="text-xl font-bold mb-4">Further resources</h2>
          <p className="mb-4">For more information about {condition.name.toLowerCase()}, you may find these resources helpful:</p>
          <ul className="space-y-2">
            <li>
              <a href="#" className="phb-link">Asthma PHB guidelines</a>
            </li>
            <li>
              <a href="#" className="phb-link">How to use your inhaler correctly</a>
            </li>
            <li>
              <a href="#" className="phb-link">Asthma action plan template</a>
            </li>
            <li>
              <a href="#" className="phb-link">Find your local asthma support group</a>
            </li>
          </ul>
        </section>
      </div>
    </div>
  );
};

export default HealthConditionPage;
