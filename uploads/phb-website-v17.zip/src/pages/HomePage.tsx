import React from 'react';
import HeroSection from '../components/HeroSection';
import HealthAZSection from '../components/HealthAZSection';
import ManageHealthSection from '../components/ManageHealthSection';
import PHBServicesSection from '../components/PHBServicesSection';
import FeaturedSection from '../components/FeaturedSection';
import MoreInfoSection from '../components/MoreInfoSection';

const HomePage: React.FC = () => {
  return (
    <>
      <HeroSection />
      <HealthAZSection />
      <ManageHealthSection />
      <PHBServicesSection />
      <FeaturedSection />
      <MoreInfoSection />
    </>
  );
};

export default HomePage;
