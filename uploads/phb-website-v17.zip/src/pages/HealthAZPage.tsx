import React, { useState } from 'react';

interface ConditionType { name: string; href: string }
type HealthConditionsType = Record<string, ConditionType[]>;

// Define health conditions data
const healthConditions: HealthConditionsType = {
  'A': [
    { name: 'Allergies', href: '/health-a-z/allergies' },
    { name: 'Anxiety', href: '/health-a-z/anxiety' },
    { name: 'Appendicitis', href: '/health-a-z/appendicitis' },
    { name: 'Arthritis', href: '/health-a-z/arthritis' },
    { name: 'Asthma', href: '/health-a-z/asthma' },
  ],
  'B': [
    { name: 'Back pain', href: '/health-a-z/back-pain' },
    { name: 'Blood pressure (high)', href: '/health-a-z/high-blood-pressure' },
    { name: 'Bronchitis', href: '/health-a-z/bronchitis' },
  ],
  'C': [
    { name: 'Cancer', href: '/health-a-z/cancer' },
    { name: 'Chickenpox', href: '/health-a-z/chickenpox' },
    { name: 'Chest infection', href: '/health-a-z/chest-infection' },
    { name: 'Cold sore', href: '/health-a-z/cold-sore' },
    { name: 'Common cold', href: '/health-a-z/common-cold' },
    { name: 'COVID-19', href: '/health-a-z/covid-19' },
  ],
  'D': [
    { name: 'Dementia', href: '/health-a-z/dementia' },
    { name: 'Depression', href: '/health-a-z/depression' },
    { name: 'Diabetes', href: '/health-a-z/diabetes' },
    { name: 'Diarrhea', href: '/health-a-z/diarrhea' },
  ],
  'E': [
    { name: 'Ear infection', href: '/health-a-z/ear-infection' },
    { name: 'Eczema', href: '/health-a-z/eczema' },
    { name: 'Endometriosis', href: '/health-a-z/endometriosis' },
  ],
  'F': [
    { name: 'Fever', href: '/health-a-z/fever' },
    { name: 'Flu', href: '/health-a-z/flu' },
    { name: 'Food poisoning', href: '/health-a-z/food-poisoning' },
  ],
};

const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

const HealthAZPage: React.FC = () => {
  const [activeFilter, setActiveFilter] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const handleAlphabetClick = (letter: string) => {
    setActiveFilter(letter === activeFilter ? null : letter);
    setSearchTerm('');
  };

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
    setActiveFilter(null);
  };

  // Filter conditions based on search or active filter
  const filteredConditions = () => {
    const result: { letter: string; conditions: ConditionType[] }[] = [];

    if (searchTerm) {
      // Search through all conditions
      Object.entries(healthConditions).forEach(([letter, conditions]) => {
        const matchingConditions = conditions.filter(condition =>
          condition.name.toLowerCase().includes(searchTerm.toLowerCase())
        );

        if (matchingConditions.length > 0) {
          result.push({ letter, conditions: matchingConditions });
        }
      });
    } else if (activeFilter && healthConditions[activeFilter]) {
      // Show only the active filter letter
      result.push({
        letter: activeFilter,
        conditions: healthConditions[activeFilter]
      });
    } else {
      // Show all conditions organized by letter
      Object.entries(healthConditions).forEach(([letter, conditions]) => {
        result.push({ letter, conditions });
      });
    }

    return result;
  };

  return (
    <div className="bg-white">
      <div className="bg-[#005eb8] text-white py-8">
        <div className="phb-container">
          <h1 className="text-3xl font-bold mb-4">Health A to Z</h1>
          <p className="text-xl font-medium">Find conditions and treatments information by selecting a letter</p>
        </div>
      </div>

      <div className="phb-container py-8">
        {/* Search */}
        <div className="mb-8">
          <label htmlFor="health-search" className="block font-bold mb-2">Search health conditions</label>
          <div className="flex max-w-xl">
            <input
              type="search"
              id="health-search"
              placeholder="Search by condition or symptom"
              className="px-4 py-2 border border-gray-300 rounded-l-md w-full focus:outline-none focus:ring-2 focus:ring-[#005eb8]"
              value={searchTerm}
              onChange={handleSearch}
            />
            <button
              type="submit"
              className="bg-[#005eb8] hover:bg-[#003f7e] text-white px-4 py-2 rounded-r-md"
            >
              Search
            </button>
          </div>
        </div>

        {/* Alphabet navigation */}
        <div className="mb-8">
          <h2 className="text-xl font-bold mb-4">Browse by letter</h2>
          <div className="flex flex-wrap gap-2">
            {alphabet.map(letter => (
              <button
                key={letter}
                onClick={() => handleAlphabetClick(letter)}
                className={`w-10 h-10 flex items-center justify-center rounded-md font-bold text-lg
                  ${activeFilter === letter
                    ? 'bg-[#005eb8] text-white'
                    : healthConditions[letter]
                      ? 'bg-gray-100 hover:bg-gray-200 text-[#005eb8]'
                      : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                  }`}
                disabled={!healthConditions[letter]}
              >
                {letter}
              </button>
            ))}
          </div>
        </div>

        {/* Conditions list */}
        <div>
          {filteredConditions().map(({ letter, conditions }) => (
            <div key={letter} className="mb-8">
              <h2 id={`letter-${letter}`} className="text-2xl font-bold mb-4 text-[#005eb8] border-b border-gray-200 pb-2">
                {letter}
              </h2>
              <ul className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {conditions.map((condition, index) => (
                  <li key={index}>
                    <a
                      href={condition.href}
                      className="text-[#005eb8] hover:underline font-medium flex items-center"
                    >
                      <svg className="h-5 w-5 mr-2 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                      </svg>
                      {condition.name}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          {filteredConditions().length === 0 && (
            <div className="bg-gray-100 p-6 rounded-md">
              <h3 className="text-lg font-bold mb-2">No conditions found</h3>
              <p>Try searching with a different term or browse by letter.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default HealthAZPage;
