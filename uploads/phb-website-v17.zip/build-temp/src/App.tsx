import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

// Layouts
import MainLayout from './layouts/MainLayout';
import ProfessionalLayout from './layouts/ProfessionalLayout';

// Pages
import HomePage from './pages/HomePage';
import HealthAZPage from './pages/HealthAZPage';
import HealthConditionPage from './pages/HealthConditionPage';
import LiveWellPage from './pages/LiveWellPage';
import MentalHealthPage from './pages/MentalHealthPage';
import CareAndSupportPage from './pages/CareAndSupportPage';
import PregnancyPage from './pages/PregnancyPage';
import BMICalculatorPage from './pages/BMICalculatorPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import AccountPage from './pages/AccountPage';
import DueDateCalculatorPage from './pages/DueDateCalculatorPage';
import KickCounterPage from './pages/KickCounterPage';
import ContractionTimerPage from './pages/ContractionTimerPage';
import WeightGainCalculatorPage from './pages/WeightGainCalculatorPage';
import PregnancyCalendarPage from './pages/PregnancyCalendarPage';
import BabyNamesDirectoryPage from './pages/BabyNamesDirectoryPage';
import BabyShowerPlannerPage from './pages/BabyShowerPlannerPage';
import PregnancyNutritionGuidePage from './pages/PregnancyNutritionGuidePage';
import BirthPlanCreatorPage from './pages/BirthPlanCreatorPage';

// Professional Pages
import ProfessionalLoginPage from './pages/professional/ProfessionalLoginPage';
import ProfessionalRegisterPage from './pages/professional/ProfessionalRegisterPage';
import ProfessionalDashboardPage from './pages/professional/ProfessionalDashboardPage';
import ProfessionalCalculatorsPage from './pages/professional/ProfessionalCalculatorsPage';
import ResearchPage from './pages/professional/ResearchPage';

// Features
import { AuthProvider } from './features/auth/authContext';
import { ProfessionalAuthProvider } from './features/professional/professionalAuthContext';
import ProfessionalRouteGuard from './features/professional/ProfessionalRouteGuard';
import GPHealthRecord from './features/health/GPHealthRecord';
import Prescriptions from './features/health/Prescriptions';
import Appointments from './features/health/Appointments';
import TestResults from './features/health/TestResults';

function App() {
  return (
    <AuthProvider>
      <ProfessionalAuthProvider>
        <Router>
          <Routes>
            {/* Main layout routes */}
            <Route path="/" element={<MainLayout />}>
              <Route index element={<HomePage />} />
              <Route path="health-a-z" element={<HealthAZPage />} />
              <Route path="health-a-z/:conditionSlug" element={<HealthConditionPage />} />
              <Route path="live-well" element={<LiveWellPage />} />
              <Route path="mental-health" element={<MentalHealthPage />} />
              <Route path="care-and-support" element={<CareAndSupportPage />} />

              {/* Pregnancy Pages */}
              <Route path="pregnancy" element={<PregnancyPage />} />
              <Route path="pregnancy/calendar" element={<PregnancyCalendarPage />} />
              <Route path="pregnancy/baby-names-directory" element={<BabyNamesDirectoryPage />} />
              <Route path="pregnancy/baby-shower-planner" element={<BabyShowerPlannerPage />} />
              <Route path="pregnancy/nutrition-guide" element={<PregnancyNutritionGuidePage />} />
              <Route path="pregnancy/birth-plan-creator" element={<BirthPlanCreatorPage />} />

              {/* Tools */}
              <Route path="tools/bmi-calculator" element={<BMICalculatorPage />} />
              <Route path="tools/due-date-calculator" element={<DueDateCalculatorPage />} />
              <Route path="tools/kick-counter" element={<KickCounterPage />} />
              <Route path="tools/contraction-timer" element={<ContractionTimerPage />} />
              <Route path="tools/weight-gain-calculator" element={<WeightGainCalculatorPage />} />

              {/* Account and Health Dashboard */}
              <Route path="account" element={<AccountPage />} />
              <Route path="account/gp-record" element={<GPHealthRecord />} />
              <Route path="account/prescriptions" element={<Prescriptions />} />
              <Route path="account/appointments" element={<Appointments />} />
              <Route path="account/test-results" element={<TestResults />} />
            </Route>

            {/* Professional layout routes */}
            <Route path="/professional" element={<ProfessionalLayout />}>
              <Route path="dashboard" element={
                <ProfessionalRouteGuard>
                  <ProfessionalDashboardPage />
                </ProfessionalRouteGuard>
              } />
              <Route path="calculators" element={
                <ProfessionalRouteGuard>
                  <ProfessionalCalculatorsPage />
                </ProfessionalRouteGuard>
              } />
              <Route path="research" element={
                <ProfessionalRouteGuard allowedRoles={['researcher', 'doctor']}>
                  <ResearchPage />
                </ProfessionalRouteGuard>
              } />
            </Route>

            {/* Standalone pages (no header/footer) */}
            <Route path="login" element={<LoginPage />} />
            <Route path="register" element={<RegisterPage />} />
            <Route path="professional/login" element={<ProfessionalLoginPage />} />
            <Route path="professional/register" element={<ProfessionalRegisterPage />} />

            {/* Catch all for 404 - can be replaced with a NotFoundPage component */}
            <Route path="*" element={<div>Page not found</div>} />
          </Routes>
        </Router>
      </ProfessionalAuthProvider>
    </AuthProvider>
  );
}

export default App;
