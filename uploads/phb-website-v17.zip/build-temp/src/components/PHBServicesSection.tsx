import React from 'react';

const PHBServicesSection: React.FC = () => {
  const serviceLinks = [
    {
      href: '/find-pharmacy',
      text: 'Find a pharmacy',
    },
    {
      href: '/find-dentist',
      text: 'Find a dentist',
    },
    {
      href: '/find-gp',
      text: 'Find a GP',
    },
    {
      href: '/find-therapy',
      text: 'Find a PHB talking therapies service',
    },
  ];

  return (
    <section className="bg-gray-100 py-8">
      <div className="phb-container">
        <h2 className="text-2xl font-bold mb-6">PHB services</h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="col-span-1 md:col-span-2">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {serviceLinks.map((link, index) => (
                <a
                  key={index}
                  href={link.href}
                  className="bg-[#005eb8] text-white p-4 rounded-md flex items-center justify-between hover:bg-[#003f7e] transition-colors"
                >
                  <span className="font-medium">{link.text}</span>
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                    <path strokeLinecap="round" strokeLinejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                  </svg>
                </a>
              ))}
            </div>

            <div className="mt-4">
              <a href="/all-services" className="flex items-center text-[#005eb8] hover:underline">
                <svg
                  className="h-5 w-5 mr-2 flex-shrink-0 text-green-600"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M13 7l5 5m0 0l-5 5m5-5H6"
                  />
                </svg>
                <span className="font-medium">Find other PHB services</span>
              </a>
            </div>
          </div>

          <div className="col-span-1">
            <div className="bg-white p-6 rounded-md shadow-sm">
              <h3 className="text-xl font-bold mb-4">Help from PHB 111</h3>
              <p className="mb-4">
                If you're worried about a symptom and not sure what help you need, PHB 111 can tell you what to do next.
              </p>
              <p className="mb-2">
                Go to <a href="https://111.phb.uk" className="phb-link">111.phb.uk</a> or <a href="tel:111" className="phb-link">call 111</a>.
              </p>
              <p>
                For a life-threatening emergency call 999.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PHBServicesSection;
