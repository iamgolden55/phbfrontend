import React from 'react';

const Footer: React.FC = () => {
  const supportLinks = [
    { text: 'Home', href: '/' },
    { text: 'Health A to Z', href: '/health-a-z' },
    { text: 'Live Well', href: '/live-well' },
    { text: 'Mental health', href: '/mental-health' },
    { text: 'Care and support', href: '/care-and-support' },
    { text: 'Pregnancy', href: '/pregnancy' },
    { text: 'PHB services', href: '/phb-services' },
    { text: 'Coronavirus (COVID-19)', href: '/conditions/covid-19' },
  ];

  const appLinks = [
    { text: 'PHB App', href: '/phb-app' },
    { text: 'Find my PHB number', href: '/find-phb-number' },
    { text: 'View your GP health record', href: '/view-gp-health-record' },
    { text: 'View your test results', href: '/test-results' },
    { text: 'About the PHB', href: '/about-the-phb' },
    { text: 'Healthcare abroad', href: '/healthcare-abroad' },
  ];

  const otherLinks = [
    { text: 'Other PHB websites', href: '/phb-sites' },
    { text: 'Profile editor login', href: '/profile-editor-login' },
  ];

  const aboutLinks = [
    { text: 'About us', href: '/about-us' },
    { text: 'Give us feedback', href: '/feedback' },
    { text: 'Accessibility statement', href: '/accessibility-statement' },
    { text: 'Our policies', href: '/our-policies' },
    { text: 'Cookies', href: '/cookies-policy' },
  ];

  return (
    <footer className="bg-gray-200 pt-8 pb-4">
      <div className="phb-container">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <h3 className="text-sm font-bold mb-4">Support links</h3>
            <ul className="space-y-2 text-sm">
              {supportLinks.map((link, index) => (
                <li key={index}>
                  <a href={link.href} className="text-[#005eb8] hover:underline">
                    {link.text}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-bold mb-4">PHB App and services</h3>
            <ul className="space-y-2 text-sm">
              {appLinks.map((link, index) => (
                <li key={index}>
                  <a href={link.href} className="text-[#005eb8] hover:underline">
                    {link.text}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-bold mb-4">Other resources</h3>
            <ul className="space-y-2 text-sm">
              {otherLinks.map((link, index) => (
                <li key={index}>
                  <a href={link.href} className="text-[#005eb8] hover:underline">
                    {link.text}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-bold mb-4">About PHB</h3>
            <ul className="space-y-2 text-sm">
              {aboutLinks.map((link, index) => (
                <li key={index}>
                  <a href={link.href} className="text-[#005eb8] hover:underline">
                    {link.text}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-4 border-t border-gray-300">
          <p className="text-sm text-gray-600">© Crown copyright</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
