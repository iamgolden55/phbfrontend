import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import PHBLogo from './PHBLogo';
import { useAuth } from '../features/auth/authContext';

const Header: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const { user, isAuthenticated, logout } = useAuth();

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle search logic
    console.log('Searching for:', searchTerm);
  };

  const handleLogout = () => {
    logout();
  };

  return (
    <header>
      {/* Cookie banner - similar to NHS */}
      <div className="bg-white p-4 border-b">
        <div className="phb-container">
          <h2 className="text-lg font-bold mb-2">Cookies on the PHB website</h2>
          <p className="mb-2">We've put some small files called cookies on your device to make our site work.</p>
          <p className="mb-2">
            We'd also like to use analytics cookies. These collect feedback and send information about how our site is
            used to services called Adobe Analytics, Adobe Target, Qualtrics Feedback and Google Analytics. We use this
            information to improve our site.
          </p>
          <p className="mb-4">
            Let us know if this is OK. We'll use a cookie to save your choice. You can{' '}
            <a href="#" className="phb-link">read more about our cookies</a>{' '}
            before you choose.
          </p>
          <div className="flex flex-col sm:flex-row gap-2">
            <button className="phb-button bg-green-600 hover:bg-green-700">I'm OK with analytics cookies</button>
            <button className="phb-button bg-gray-600 hover:bg-gray-700">Do not use analytics cookies</button>
          </div>
        </div>
      </div>

      {/* Main header - PHB logo and search */}
      <div className="bg-[#005eb8] text-white">
        <div className="phb-container py-4 flex flex-col md:flex-row justify-between items-center">
          <Link to="/" className="mb-4 md:mb-0">
            <PHBLogo />
          </Link>

          <div className="w-full md:w-auto">
            <form onSubmit={handleSearchSubmit} className="flex">
              <input
                type="search"
                placeholder="Search"
                value={searchTerm}
                onChange={handleSearchChange}
                className="px-3 py-2 text-black rounded-l-md w-full md:w-64 focus:outline-none"
                aria-label="Search the PHB website"
              />
              <button
                type="submit"
                className="bg-[#003f7e] hover:bg-[#002c5c] px-4 py-2 rounded-r-md"
                aria-label="Submit search"
              >
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                  <path strokeLinecap="round" strokeLinejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />
                </svg>
              </button>
            </form>
          </div>

          {isAuthenticated ? (
            <div className="hidden md:flex items-center gap-4 text-white mt-4 md:mt-0">
              <div className="flex items-center gap-2">
                <div className="bg-[#003f7e] rounded-full h-8 w-8 flex items-center justify-center font-bold">
                  {user?.name.charAt(0)}
                </div>
                <div className="flex flex-col">
                  <span className="text-sm font-medium">{user?.name}</span>
                  <div className="flex items-center gap-3">
                    <Link to="/account" className="text-xs text-white hover:underline">
                      My account
                    </Link>
                    <button
                      onClick={handleLogout}
                      className="text-xs text-white hover:underline"
                    >
                      Sign out
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="hidden md:flex items-center gap-4 text-white mt-4 md:mt-0">
              <Link to="/login" className="text-white hover:underline flex items-center gap-1">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0 0 13.5 3h-6a2.25 2.25 0 0 0-2.25 2.25v13.5A2.25 2.25 0 0 0 7.5 21h6a2.25 2.25 0 0 0 2.25-2.25V15m3 0 3-3m0 0-3-3m3 3H9" />
                </svg>
                Sign in
              </Link>
              <Link
                to="/register"
                className="bg-white text-[#005eb8] px-3 py-1 rounded hover:bg-gray-100 transition-colors"
              >
                Register
              </Link>
            </div>
          )}
        </div>
      </div>

      {/* Navigation */}
      <nav className="bg-[#005eb8] border-t border-[#3373b5] text-white">
        <div className="phb-container">
          <ul className="flex flex-wrap">
            <li className="px-2 py-3 md:px-4 hover:bg-[#003f7e] transition-colors">
              <Link to="/health-a-z" className="text-sm md:text-base font-medium">Health A-Z</Link>
            </li>
            <li className="px-2 py-3 md:px-4 hover:bg-[#003f7e] transition-colors">
              <Link to="/live-well" className="text-sm md:text-base font-medium">Live Well</Link>
            </li>
            <li className="px-2 py-3 md:px-4 hover:bg-[#003f7e] transition-colors">
              <Link to="/mental-health" className="text-sm md:text-base font-medium">Mental health</Link>
            </li>
            <li className="px-2 py-3 md:px-4 hover:bg-[#003f7e] transition-colors">
              <Link to="/care-and-support" className="text-sm md:text-base font-medium">Care and support</Link>
            </li>
            <li className="px-2 py-3 md:px-4 hover:bg-[#003f7e] transition-colors">
              <Link to="/pregnancy" className="text-sm md:text-base font-medium">Pregnancy</Link>
            </li>
            <li className="px-2 py-3 md:px-4 hover:bg-[#003f7e] transition-colors">
              <Link to="/phb-services" className="text-sm md:text-base font-medium">PHB services</Link>
            </li>
          </ul>
        </div>
      </nav>
    </header>
  );
};

export default Header;
